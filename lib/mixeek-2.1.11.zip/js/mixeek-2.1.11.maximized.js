/*
Copyright 2013 Stepan Kukal
http://www.mixeek.com/

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
/**
 * @author <a href="mailto:stepan@mixeek.com">Stepan Kukal</a>
 */

	 /**
	 * @ignore
	 */
	window.originalSetInterval = window.setInterval;
	/**
	 * @ignore
	 */
	window.originalClearInterval = window.clearInterval;
	window.activeIntervals = 0;
	/**
	 * @ignore
	 */
	window.setInterval = function (func, delay)
	{
		if(func && delay){
				window.activeIntervals++;
		}
		return window.originalSetInterval(func,delay);
	};
	/**
	 * @ignore
	 */
	window.clearInterval = function (intervalId)
	{
		// JQuery sometimes hands in true which doesn't count
		if(intervalId !== true){
			window.activeIntervals--;
		}
		return window.originalClearInterval(intervalId);
	};
	
	//some shared variables
	var isH5 = false;
	var isCSS3 = false;
	var css3Counter = 0;

	var isWebKit = false;
	var isIE = false;
	var isIE6 = false;
	var isIE7 = false;
	var isIE8 = false;
	var isIE9 = false;
	var isIE10 = false;
	var isSafari = false;
	var isOpera = false;
	var isMozilla = false;
	var mxkIsAndroid = false;
	var browserPrefix = "";
	var DEF_FPS = 100;//40
	/**
	 * @ignore
	 */
	function checkBrowser() {
		var ua = navigator.userAgent.toLowerCase();
		mxkIsAndroid = ua.indexOf("android") > -1; 
		if($.browser.msie) {
			isIE = true;
			if($.browser.version == "6.0")
				isIE6 = true;
			else if($.browser.version == "7.0")
				isIE7 = true;
			else if($.browser.version == "8.0")
				isIE8 = true;
			else if($.browser.version == "9.0")
				isIE9 = true;
			else if($.browser.version == "10.0")
				isIE10 = true;
			browserPrefix = "-ms-";
		}
		else if($.browser.webkit || $.browser.safari) {
			isWebKit = true;
			browserPrefix = "-webkit-";
		}
		else if($.browser.safari) {
			isSafari = true;
			browserPrefix = "-webkit-";
		}
		else if($.browser.opera) {
			isOpera = true;
			browserPrefix = "-o-";
		}
		else if($.browser.mozilla) {
			isMozilla = true;
			browserPrefix = "-moz-";
		}
		
	}
	checkBrowser();

	/**
	 * @ignore
	 */
	function testBrowserFeatures() {
		var canCss3 = false;
		var canCss3D = false;
		var canHtml5 = false;
		var canAudio = false;
		
	   document.write('<div id="css_test" style="position:absolute;top:-1000px;left:-1000px;-webkit-transform: translate(-1000px,-1000px) rotate(7deg) scale(0.5) translate3d(-1000px,-1000px,0px) rotateZ(5deg) scale3d(0.5,0.5,1);-ms-transform:translate(-1000px,-1000px) rotate(7deg) scale(0.5) translate3d(-1000px,-1000px,0px) rotateZ(5deg) scale3d(0.5,0.5,1);transform:translate(-1001px,-1001px)  rotate(7deg)  scale(0.5) translate3d(-1000px,-1000px,0px) rotateZ(5deg) scale3d(0.5,0.5,1);-moz-transform:translate(-1000px,-1000px) rotate(7deg) scale(0.5) translate3d(-1000px,-1000px,0px) rotateZ(5deg) scale3d(0.5,0.5,1);-o-transform:translate(-1000px,-1000px) rotate(7deg) scale(0.5) translate3d(-1000px,-1000px,0px) rotateZ(5deg) scale3d(0.5,0.5,1);animation:mxkagentcheck 1s linear;-webkit-animation:mxkagentcheck 1s linear;">A</div>');
		//css3 stuff
		//-css3 transform
		var myDiv = document.getElementById('css_test');
		var transform = myDiv.style.transform;
		var msTransform = myDiv.style.msTransform;
		var webkitTransform = myDiv.style.webkitTransform;
		var mozTransform = myDiv.style.mozTransform;
		var oTransform = myDiv.style.oTransform;
		var uTransform = transform;
		if(!uTransform)
			uTransform = msTransform;
		if(!uTransform)
			uTransform = mozTransform;
		if(!uTransform)
			uTransform = webkitTransform;
		if(!uTransform)
			uTransform = oTransform;
		var uAnimation = myDiv.style.animation || myDiv.style.webkitAnimation;
		if(uTransform) {
			canCss3 = 
				uTransform.indexOf("translate") != -1
				&& uTransform.indexOf("rotate") != -1
				&& uTransform.indexOf("scale") != -1
				&& uAnimation != null && uAnimation != undefined;
			canCss3D = 
				uTransform.indexOf("translate3d") != -1
				&& uTransform.indexOf("rotateZ") != -1
				&& uTransform.indexOf("scale3d") != -1;
				
		}
		var canvas = document.createElement("canvas");
		canvas.id = "testCanvas";
		canvas.style.position = "absolute";
		canvas.style.top = "-1000px";
		canvas.style.left = "-1000px";
		document.body.appendChild(canvas);
		if(document.getElementById("testCanvas"))
			canHtml5 = true;
		var result = {canCss3:canCss3, canCss3D:canCss3D, canHtml5:canHtml5 };
//		alert(JSON.stringify(result));
		return result;
	}
	var bFeatures = testBrowserFeatures();
	

	/**
	 * @ignore
	 */
	jQuery.fn.redraw = function() {
		this.hide();
		this.show();
	};	
	/**
	 * Sets prefered playback mode: "CSS3" = CSS3 transitional animations, or "JS" = JavaScript animation. If not set then "CSS3" is default.
	 * @param {String} mode "CSS3" or "JS" 
	 */
	function setPlaybackMode(mode) {
		if(mode == 'HTML5' || mode == 'html5') {
			isH5 = bFeatures.canHtml5;
			if(!isH5)
				mode = 'CSS3'; //try css3 as a fallback
			else
				isCSS3 = false;
		}
		if(mode == 'CSS3' || mode == 'css3') {
			isCSS3 = bFeatures.canCss3;
		} else if( mode == 'JS' || mode == 'js' ){
			isCSS3 = false;
		}
/* older
		if(mode == 'HTML5' || mode == 'html5') {
			isH5 = !(isIE6 || isIE7 || isIE8);
			if(!isH5)
				mode = 'CSS3'; //try css3 as a fallback
			else
				isCSS3 = false;
		}
		if(mode == 'CSS3' || mode == 'css3') {
			isCSS3 = !(isIE6 || isIE7 || isIE8 || isIE9);
		} else if( mode == 'JS' || mode =='js' ){
			isCSS3 = false;
		}
*/
	}
	setPlaybackMode('CSS3');
	   
	   
	//CANVAS
	var MXKCANVAS = null;
	//MXKIMAGES (MxkImageCache)
	var MXKIMAGES = null;
	var MXKSOUNDS = null;

	var S_PREFIX = "mxks_";
	var C_MP3 = ".mp3";
	var C_OGG = ".ogg";
	var C_AAC = ".aac";
	var C_WAV = ".wav";
	var T_MP3 = "audio/mpeg";
	var T_OGG = "audio/ogg";
	var T_AAC = "audio/mp4";
	var T_WAV = "audio/wav";
	/**
	 * @class Shared sound cache
	 * @ignore
	 */
	function MxkSoundCache() {
		this.lSnds = 0; //TODO loading check as for images
		this.isAny = false;
		this.soundNames = {};
		/**
		 * @ignore
		 */
		this.getExtForType = function(type) {
			if(type === T_MP3)
				return C_MP3;
			else if(type === T_OGG) //TODO correct audio types
				return C_OGG;
			else if(type === T_AAC) //TODO correct audio types
				return C_AAC;
			else if(type === T_WAV) //TODO correct audio types
				return C_WAV;
		};
		/**
		 * @ignore
		 */
		this.getTypeForExt = function(ext) {
			if(ext === C_MP3)
				return T_MP3;
			else if(ext === C_OGG) //TODO correct audio exts
				return T_OGG;
			else if(ext === C_AAC) //TODO correct audio exts
				return T_AAC;
			else if(ext === C_WAV) //TODO correct audio exts
				return T_WAV;
		};
		this.addSound = function(name, type, dataUri) {
			console.log('MXK: addSound ' + name +  ' ' + type );
			this.isAny = true;
			if(!this.soundNames[name])
				this.soundNames[name] = {};
			if(this.soundNames[name][type])
				return;
			this.lSnds++;
			var ext = this.getExtForType(type);
			var audio = $("<audio preload='auto' id='"+S_PREFIX+name+ext+"'><source src='"+dataUri+"' type='"+type+"'></source></audio>").on("loadeddata", function() {
//				console.log("MXK: ON canplay " + type + " " + name);
//				if(! $(this).data('loaded')) {
//					this.pause();
//					$(this).data('loaded', true);
//				}
				console.log("MXK: loaded adnroid");
	
				if(mxkIsAndroid) {
					console.log("MXK: ON canplay " + type + " " + name);
					this.pause();
				}
				MXKSOUNDS.lSnds--;
				if(MXKSOUNDS.lSnds < 0)
					MXKSOUNDS.lSnds = 0;
			}).appendTo("body");
//			console.log(audio.html());
			if(mxkIsAndroid) {
				audio[0].play();
			}
			var canplay = audio[0].canPlayType(type);
			if(!canplay) {
				console.log("MXK: CANT PLAY " + type + " " + name);
				MXKSOUNDS.lSnds--;
				if(MXKSOUNDS.lSnds < 0)
					MXKSOUNDS.lSnds = 0;
			}
			this.soundNames[name][type] = {src: dataUri, ext: ext}; //TODO any other attribute needed? OR NEEDED AT ALL?
			console.log('MXK: addSound END');
		};

		/**
		 * @ignore
		 */
		this.getSoundNames = function() {
			var names = [];
			for(var name in this.soundNames) {//copy sound names into separate array
				var nameExt = this.getDisplayName(name);
				names.push(nameExt);
			}
			return names;
		};
		/**
		 * @ignore
		 */
		this.getDisplayName = function(name) {
			var nameExt = name + " [";
			var first = true;
			for(var type in this.soundNames[name]) {
				var ext = this.getExtForType(type);
				if(first) {
					first = false;
				} else {
					nameExt += ","
				}
				nameExt += ext;
			}
			nameExt += "]";
			return nameExt;
		};

		this.playingIds = {};
		/**
		 * @ignore
		 */
		this.playSound = function(name, type) {
//			console.log('MXK: playSound ' + name);
			var soundId = null;
			if(type) {
				soundId = S_PREFIX + name + this.soundNames[name][type].ext;
				var el = document.getElementById(soundId);
//				if(!el.ended && 0 < el.currentTime) { //audio playing
//					this.clearSound(el);
//TODO				}
				if(el.canPlayType(type)) {
					el.pause();
					try {
						el.currentTime = 0;
					} catch(err) {
//						el.src = el.src;
					}
					el.play(); //TODO maybe event synchornization (canplay) this.lSnds
					this.playingIds[soundId] = soundId;
					console.log('MXK: playSound  end ' + soundId);
					return soundId;
				}
			}
			var sound = this.soundNames[name];
			for(var type in sound) {
				soundId = S_PREFIX + name + sound[type].ext;
				var el = document.getElementById(soundId);
//				if(!el.ended && 0 < el.currentTime) { //audio playing
//					this.clearSound(el);
//				}
				if(el.canPlayType(type)) {
					el.pause();
					try {
						el.currentTime = 0;
					} catch(err) {
//						el.src = el.src;
					}
					el.play(); //TODO maybe event synchornization (canplay) this.lSnds
					this.playingIds[soundId] = soundId;
					console.log('MXK: playSound  end ' + soundId);
					return soundId;
				}
			}
//			console.log('MXK: playSound  end NO SOUND');
			return null;
		};
		/**
		 * @ignore
		 */
		this.clearSound = function(element) {
			element.pause();
			try {
				element.currentTime = 0;
			} catch(err) {
//						el.src = el.src;
			}
			this.playingIds[element.id] = null;
		};
		/**
		 * @ignore
		 */
		this.clearSounds = function() {
			for(var id in this.playingIds) {
				var sid = this.playingIds[id];
				if(sid)
					this.clearSound(document.getElementById(sid));
			}
			this.playingIds = {};
		};
	}
	
	
	/**
	 * @class Shared image cache
	 * @ignore
	 */
	function MxkImageCache() {
		this.lImgs = 0;
		this.images = [];
		this.styleBlock = $("<style type='text/css'></style>").appendTo("head");
		
		/**
		 * @ignore
		 */
		this.addImage = function(name, image) {
			this.images[name] = image;
		};

		this.imageNames = {};
		/**
		 * @ignore
		 * IE9+
		 */
		this.addImageClass = function(name, dataUri, width, height) {
			if(this.imageNames[name])
				return;
			var clas = "."+name+"{background-image:url('"+dataUri+"'); width:"+width+"px; height:"+height+"px;}";
			this.styleBlock.append(clas);
			this.imageNames[name] = {width:width, height:height, src: dataUri};
		};

		this.heights = {};
		/**
		 * @ignore
		 */
		this.addHeightClass = function(name, height) {
			if(this.heights[name])
				return;
			var clas = "."+name+"{height:"+height+"px !important;}";
			this.styleBlock.append(clas);
			this.heights[name] = name;
		};
		/**
		 * @ignore
		 */
		this.getImageNames = function() {
			var narray = isIE8? this.images : this.imageNames;
			var names = [];
			for(var name in narray) {//copy image names into separate array
				names[names.length] = name;
			}
			return names;
		};
		/**
		 * @ignore
		 */
		this.getImage = function(name) {
			return this.images[name];
		};
	}

	var spriteRegistry = {};
	var spriteRegistryH5 = [];
	var runningRegistry = {};
	var loop;
	var ix = 0;
	var h5ClockStart, h5Clock, h5ClockFirst, h5PauseClock, useH5PauseClock;

	var FPS_INV;
	var FPS;
	//TODO function to update FPS_INV on the fly

	/**
	 * @ignore
	 * Set animation speed "Frames Per Second"
	 * @param {Number} fps FPS
	 */
	function setFPS(fps) {
	   FPS = fps;
	   FPS_INV = ( 1000 / fps );
	   if(isEdit())
			FPS_INV *= 0.7; //JS is slow in editor
	};
	setFPS(DEF_FPS);

		
//	var mozReload = true;
	var isAnimationLoop = false;
	/**
	 * Starts the animation loop. If this is not called, no animations can be started on particular Sprites
	 */
	function startAnimationLoop() {
		if( isAnimationLoop && !isCSS3 )
			return;
		if( MXKIMAGES.lImgs != 0 || MXKSOUNDS.lSnds != 0) {
//			console.log('MXK: startAnimationLoop delaying ' + MXKSOUNDS.lSnds +  ' ' + MXKIMAGES.lImgs);
			setTimeout(function() {
				startAnimationLoop()
			}, 10);
			return;
		}
/*		if(isFullReload && isMozilla && mozReload) {
			mozReload = false;
			setTimeout(function() {
				startAnimationLoop()
			}, 100);
			return;
		}*/
		isAnimationLoop = true;
		if(isH5) {
			for(var i in canvases) {
				canvases[i].applyStyle();
			}
			//setup timing
			if (!window.requestAnimationFrame) {
				window.requestAnimationFrame = (function () {
					return window.webkitRequestAnimationFrame ||
					window.mozRequestAnimationFrame ||
					window.oRequestAnimationFrame ||
					window.msRequestAnimationFrame ||
					function ( callback,element) {
						window.setTimeout(callback, 17); // Fallback timeout
					};
				})();
			}
			if(!h5ClockFirst)
				h5ClockFirst = true;
			requestAnimationFrame(animationLoopH5);
		} else if(isCSS3) {
			for(var name in runningRegistry) {
				var sprite = runningRegistry[name];
				sprite.animation.createCSS3( sprite, sprite.playFrom, sprite.playTo );
				sprite.animation.startCss3( sprite.animation.css3KeyframesNames[sprite.playFrom+'-'+sprite.playTo+'-'+parseInt(sprite.canvas.GLOBAL_SCALE * 100)], sprite.duration );
			}
			for(var name in runningRegistry) {
				var sprite = runningRegistry[name];
				sprite.update();
				sprite.imgObj.removeClass("css3Paused");
				sprite.imgObj.css(sprite.styleToPlay);					
			}
			runningRegistry = {};
		} else {
			loop = setInterval( "animationLoop()", FPS_INV);
		}
	}

	/**
	 * Stop the animation loop. After this no animation will be happening.
	 */
	function stopAnimationLoop() {
		isAnimationLoop = false;
		//h5ClockFirst = true; //h5 for sure
		clearInterval(loop);
	}
	
	var bak = [];
	/**
	 * @ignore
	 */
	function animationLoop() {
		ix++;
		bak.length = 0;
		for(var name in runningRegistry) {
			bak[name] = runningRegistry[name];
		}
		for(var name in bak) {
//			if(spriteRegistry.hasOwnProperty(name))
				bak[name].animate();
		}
		for(var name in bak) {
				if(bak[name].ix == ix) {
					bak[name].update(false, true);
				}
		}
		MXKCANVAS.getPosition(); //force redraw
	}
	/**
	 * @ignore
	 */
	function animationLoopH5() {
		sortH5(spriteRegistryH5);
		if(h5ClockFirst) {
			h5ClockFirst = false;
			h5ClockStart = new Date().getTime();
			h5Clock = 0;

			for(var i in canvases) {
				canvases[i].isH5Redraw = true;
//				canvases[i].clearH5();
			}
//			for(var name in spriteRegistryH5) {
//				if(!spriteRegistryH5[name].parentSprite)
//					spriteRegistryH5[name].updateH5();
//			}
			redrawH5(true); //force redraw
			
		} else if(h5PauseClock && useH5PauseClock) {
			h5Clock = h5PauseClock;
			h5ClockStart = new Date().getTime() - h5Clock;
//			h5PauseClock = 0;
			useH5PauseClock = false;
		} else {
			h5Clock = new Date().getTime() - h5ClockStart;
		}
		ix++;
		bak.length = 0;
		for(var name in runningRegistry) {
			bak[name] = runningRegistry[name];
		}
		for(var name in bak) {
			bak[name].animateH5();
			bak[name].checkH5Redraw();
		}
		redrawH5(false, true);
		if(isAnimationLoop) {//stopAnimationLoop() 
			requestAnimationFrame(animationLoopH5);
//			console.log('MXK: h5 looping');
		}
	}
	
	/**
	 * @ignore
	 */
	function redrawH5(force, isSound) {
		if(h5Clock || force)
			for(var i in canvases) {
				if(canvases[i].isH5Redraw || force)
					canvases[i].clearH5();
			}
		for(var name in spriteRegistryH5) {
			if(!spriteRegistryH5[name].parentSprite)
				spriteRegistryH5[name].updateH5(isSound); //TODO distiguish fisrts frame
		}
		if(!force)
			for(var i in canvases) {
				canvases[i].isH5Redraw = false;
			}
	}

	
	var isEditP = null;
	/**
	 * @ignore
	 */
	function isEdit() {
		if(isEditP == null) {
			isEditP = (typeof MXKEDITOR != 'undefined');
		}
		return isEditP;
	}
	
	var canvas_counter = 0;
	var canvases = [];
	/**
	 * @class The drawing area. Sprites can be drawn outside of the canvas. The rectangle serves mainly for relative positioning of sprites from the top-left corner of canvas.
	 * @param {jQuery Object} parent The parent HTML container for the canvas. Canvas is represented as DIV appended to the parent node
	 * @param {Number} width The width in pixels of the container
	 * @param {Number} height The width in pixels of the container
	 * @param {String} Optional CSS attributes of the DIV container. The format is CSS inline style notation.
	 */
	function MxkCanvas(parent, width, height, style, scaleToParent) {
		canvases.push(this);
		this.scaleToParent = scaleToParent;
//		checkBrowser();
//		$("body").append($("<div id='logger'>AAA</div>")); //TODO remove
		this.id = "mxkcanvas_"+(canvas_counter++);
		if(typeof MXKCANVAS != 'undefined' && MXKCANVAS != null && isEdit()) { //physical singleton TOOD NO SINGLETONS
			MXKCANVAS.destroy();
		}
		this.parent = $(parent);
		this.width = width;
		this.height = height;
		this.origWidth = width;
		this.origHeight = height;
//		this.isOverflowHidden = true;
//		this.isRepeatX = true;
//		this.isRepeatY = true;
		
		this.GLOBAL_SCALE = 1.0;
		/**
		 * @ignore
		 */
		this.calcScale = function() {
			var pChange = false;
			var newScale;
			var pWidth = parseInt( this.parent.width() );
			var pHeight = parseInt( this.parent.height() );
			if( pWidth == 0 && pHeight == 0 ) { //zero size parent
				//nothing
				newScale = 1.0;
				if(this.GLOBAL_SCALE != newScale)
					pChange = true;
				this.GLOBAL_SCALE = newScale;
			} else if ( pHeight == 0 ) { //zero height parent
				newScale = pWidth / width;
				if(this.GLOBAL_SCALE != newScale)
					pChange = true;
				this.GLOBAL_SCALE = newScale;
			} else { //concrete size TODO maybe check css height property to be sure
				var a = width / height; //aspect ratios comparison
				var aP = pWidth / pHeight; //aspect ratios comparison
				if( a < aP)
					newScale = pHeight / height;
				else
					newScale = pWidth / width;
				if(this.GLOBAL_SCALE != newScale)
					pChange = true;
				this.GLOBAL_SCALE = newScale;
			}
			if(this.GLOBAL_SCALE != 1) {
				this.width = this.origWidth * this.GLOBAL_SCALE;
				this.height = this.origHeight * this.GLOBAL_SCALE;
//				this.applyStyle;
			}
			return pChange;
		};
		if( this.scaleToParent )
			this.calcScale(); //the scale calculation must be performed when canvas is not inside

		/**
		 * @ignore
		 */
		this.createDiv = function() {
			this.canvasDiv = $("<div id='"+this.id+"' class='mxkcanvas'></div>"); //kept original name
			this.parent.append(this.canvasDiv);
			this.style = style? style : "";

			//TODO TRY AND SEE
			this.canvasH5 = $("<canvas id='h5_"+this.id+"'></canvas>").appendTo(this.canvasDiv); //kept original name
			
			if(isEdit()) {
				this.parentWidth = parseInt( this.canvasDiv.parent().parent().width() );
				this.parentHeight = parseInt( this.canvasDiv.parent().parent().height() );
				var marginLeft = this.width/2;
				if(marginLeft > this.parentWidth/2 - 10)
					marginLeft = this.parentWidth/2 - 10;
				var marginTop = this.height/2;
				if(marginTop > this.parentHeight/2 - 10)
					marginTop = this.parentHeight/2 - 10;
				this.canvasDiv.css("margin-left", (-marginLeft) + "px");			
				this.canvasDiv.css("margin-top", (-marginTop) + "px");			
				this.canvasDiv.parent().css("width", this.parentWidth + "px");
				this.canvasDiv.parent().css("height", this.parentHeight + "px");
			}
		}
		this.createDiv();
		
		/**
		 * @ignore TODO
		 */
//		this.reattach = function() {
/*
		if( this.scaleToParent ) {
				for(var name in this.sprites) {
					this.sprites[name].stopAnimation();
				}
				this.canvasDiv.detach();
				this.parent.offset(); //or somehow force redraw
				this.calcScale(); //the scale calculation must be performed when canvas is not inside
				this.canvasDiv.appendTo(this.parent);
			}
*/
//			if( this.scaleToParent ) {
//				this.canvasDiv.remove();
//			}
//		}
		
		/**
		 * @ignore
		 */
		this.getPosition = function() {
			return this.canvasDiv.offset();
		}
		/**
		 * Sets background color of a canvas
		 * @param {Number} red red component [0..255]
		 * @param {Number} green green component [0..255]
		 * @param {Number} blue blue component [0..255]
		 * @param {Number} alpha opacity channel [0..1]
		 */
		this.setBackgroundColor = function(red, green, blue, alpha) {
			this.red = red; this.green = green; this.blue = blue; this.alpha = alpha;
		}
		/**
		 * Sets background color of a canvas
		 * @param {Boolean} isRepeatX whether to repeat background image in X axis
		 * @param {Boolean} isRepeatY whether to repeat background image in Y axis
		 */
		this.setBackgroundRepeat = function(isRepeatX, isRepeatY) {
			this.isRepeatX = isRepeatX; this.isRepeatY = isRepeatY;
		}
		/**
		 * Sets background color of a canvas
		 * @param {Boolean} allow whether to allow overflow of the canvas ("false" is equvalent to CSS style "overflow:hidden")
		 */
		this.allowOverflow = function(allow) {
			this.isOverflowHidden = !allow;
		}
		/**
		 * @ignore
		 */
		this.applyStyle = function(ignoreH5) {
			var styleNoSpace = this.style.replace(/\s/g, '');
			var values = styleNoSpace.split(";");
			var styleJson = "";//"{";
			for(var i in values) {
				if(values[i] == "") continue;
				var keyVal = values[i].split(":");
//				if(i != 0) styleJson += ",";
				styleJson += keyVal[0]+ ":" +keyVal[1]+";";
			}
			styleJson += "width:" +this.width+"px;";
			styleJson += "height:" +this.height+"px";
			
			if(this.isOverflowHidden != undefined) {
				if(this.isOverflowHidden)
					styleJson += ";overflow:hidden";
				else 
					styleJson += ";overflow:visible";
				}
			
			if(this.isRepeatX != undefined) {
				styleJson += ";background-repeat:";
				if(this.isRepeatX && this.isRepeatY)
					styleJson += "repeat";
				else if(this.isRepeatX)
					styleJson += "repeat-x";
				else if(this.isRepeatY)
					styleJson += "repeat-y";
				else
					styleJson += "no-repeat";
			}
			if(this.red != undefined) {
				styleJson += ";background-color:rgb("+this.red+","+this.green+","+this.blue+")";
				styleJson += ";background-color:rgba("+this.red+","+this.green+","+this.blue+","+this.alpha+")";
			}
			
			this.canvasDiv.css('cssText', styleJson + ";position:relative");
			if(this.canvasH5 && !ignoreH5) {
				this.canvasH5.remove();
				if(isH5) {
					//if(isEdit())
						this.canvasDiv.children().hide();
					var width = this.width+"px";
					var height = this.height+"px";
					this.canvasH5 = $("<canvas id='h5_"+this.id+"' width='"+this.width+"' height='"+this.height+"'></canvas>").appendTo(this.canvasDiv); //kept original name
				} else if(isEdit())
					this.canvasDiv.children().show();

			}
			this.resultStyle = styleJson;
			if( isEdit() ) {
				var marginLeft = this.width/2;
				if(marginLeft > this.parentWidth/2 - 10)
					marginLeft = this.parentWidth/2 - 10;
				var marginTop = this.height/2;
				if(marginTop > this.parentHeight/2 - 10)
					marginTop = this.parentHeight/2 - 10;
				this.canvasDiv.css("margin-left", (-marginLeft) + "px");			
				this.canvasDiv.css("margin-top", (-marginTop) + "px");			
				this.canvasDiv.parent().css("width", this.parentWidth + "px");
				this.canvasDiv.parent().css("height", this.parentHeight + "px");
			}
		}
		
		/**
		 * @ignore
		 * TODO maybe copy to prototype
		 */
		this.propagateToUI = function() {
			$("#canvas_width").val(this.width);
			$("#canvas_height").val(this.height);
			$("#canvas_style").val(this.style);
		}
		this.applyStyle();
		this.propagateToUI();
		/**
		 * @ignore
		 */
		this.destroy = function() {
			$("#"+this.id).remove();
		};

		/**
		 * @ignore
		 */
		this.removeImage = function() {
			if(this.activeImageName) {
				this.canvasDiv.removeClass(this.activeImageName);
			}
			this.activeImageName = undefined;
		}

		/**
		 * @ignore
		 */
		this.addImage = function(name, data, isFromSaved) {
//			$('#logger').append(" +"+name);
			MXKIMAGES.lImgs++; //increment loading images
			MXKIMAGES.loadStarted = true;
			var tempImage = $("<img id='"+name+"_tmp' src='' class='"+name+"' style='position:absolute; left:-5000px; top:0px'/>");
			tempImage.data("canvas", this);
			tempImage.load(function(self){
				if(! (isIE8||isIE7||isIE6) ) {
					loadImageCanvas( $(this), false);
				}
			});
			tempImage.attr("src", data);
			$("body").append(tempImage);
			if((isIE8||isIE7||isIE6) ) {
				setTimeout(function() {
					loadImageCanvas( tempImage, true);
				}, 10);
			}
		}
		
		
		/**
		 * Set background image to the Canvas
		 * @param {String} name unique key name of the image
		 * @param {String} data data URI encoded image
		 */
		this.setImage = function(name, data) {
			if(!name || name == "") {
				this.removeImage();
				return;
			}
			if(!MXKIMAGES.imageNames[name]) { //REUSE exiting image
				this.addImage(name, data, false);
				return;
			}

			if(!this.imageSet) {
				if(name != undefined && ( name != "" || isEdit() )) {
					this.imageSet = true;
				}
			}
			if(!name) name="";
			if(name == this.activeImageName)
				return;
			if(name!="") {
				var img = MXKIMAGES.imageNames[name];
				this.imageWidth = img.width;
				this.imageHeight = img.height;
				if(this.activeImageName)
					this.canvasDiv.removeClass(this.activeImageName)
				this.canvasDiv.addClass(name)
			}
			this.activeImageName = name;
		};

		this.sprites = {};
		/**
		 * Adds sprite to canvas. Calling of this method is mandatory since release 2.0
		 */
		this.addSprite = function(sprite) {
			this.canvasDiv.append(sprite.imgObj);
			sprite.canvas = this;
			this.sprites[sprite.name] = sprite;
		}
		/**
		 * Detaches sprite from canvas
		 */
		this.removeSprite = function(sprite) {
			sprite.imgObj.detach();
			delete this.sprites[sprite.name];
		}

		/**
		 * @ignore
		 */
		this.clearH5 = function() { //TODO Canvas STYLE: color, image, width, height
			var ctx = this.canvasH5[0].getContext('2d');
			ctx.save();
			ctx.setTransform(1, 0, 0, 1, 0, 0);
			ctx.clearRect(0, 0, this.width, this.height); //todo share width and height
			ctx.restore();		
		}

		if(!MXKCANVAS)
			MXKCANVAS = this;
	}

	
	/**
	 * @class Represents the sprite (aka "Layer"), the most important building block of the animation.
	 * @param {String} name Unique key name of the object
	 */
	function MxkSprite(name) {
		//general
		this.name = name;
//		if(index == undefined) {
		this.index = spriteRegistryH5.length;
//		} else {
//			this.index = index;
//		}
//		if(displayName == undefined) {
			this.displayName = name;
//		} else {
//			this.displayName = displayName;
//		}
		this.mode = "DEFAULT";
		this.imgObj = $("<div id='"+this.name+"' class='sprite' ></div>"); 
		if(isIE8) {
			this.imgObjSub = $("<div id='"+this.name+"_ie8' class='sprite_ie8' ></div>"); 
			this.imgObj.append(this.imgObjSub)
		}
//		this.activeImage = $("<img id='hxImg001' src='no_image.png' style='width:100%;height:100%;' />");
//		this.imgObj.append(this.activeImage);
		this.images = {};
		
		this.firstLoad = true;

		if(isEdit()) {
			this.animation = new MxkAnimation(MXKEDITOR.numOfFrames);//TODO GUI generation numOfFrames $("numOfFrames").val()); //the default animation
			this.imgObj.addClass("sprite_edit");
		} else {
			this.animation = new MxkAnimation(20);//TODO GUI generation numOfFrames $("numOfFrames").val()); //the default animation
		}
		this.animation.sprite = this;
		this.animations = [this.animation];

		/**
		 * @ignore
		 */
		this.setIndex = function(index) {
			this.index = index;
		};
		/**
		 * @ignore
		 */
		this.setDisplayName = function(displayName) {
			this.displayName = displayName;
		};
		/**
		 * @ignore
		 */
		this.enableUndo = function() {
			this.isUndo = true;
			this.updateUndoBuffer(5);
		};
		
		/**
		 * @ignore
		 */
		this.setDefaultImage = function() {
//				if(isIE8) {
					if(! MXKIMAGES.images[""]) {
						var defImage = $("<img src='select_image.png' class='sprite_image' />");
						defImage.data("width", this.width);
						defImage.data("height", this.height);
						MXKIMAGES.addImage("", defImage);
					}
					this.setImage("");
//				} else {
//					MXKIMAGES.addImageClass("", 'select_image.png', 68, 68);
//					this.setImage("");
//				}
		};
		
		this.imageNames = []; //IE9+
		/**
		 * Registers new image for a Sprite. Images are "data-uri" base64 encoded samples. There can be multiple images registered on a Sprite and they can be swithched either manually (see setImage) or by a running animation)
		 * @param {String} name Unique key name of the image
		 * @param {String} data Data URI represented image (BASE64)
		 * @param {Boolean} isFromSaved Ignore it (optional), internal control attribute.
		 */
		this.addImage = function(name, data, isFromSaved) {
			if(isIE8) {
				if(this.images[name]) { //REUSE exiting image
					this.setImage(name);
					return;
				}
			} else {//IE9+
				if(MXKIMAGES.imageNames[name]) { //REUSE exiting image
					this.setImage(name);
					return;
				}
			}
//			$('#logger').append(" +"+name);
			MXKIMAGES.lImgs++; //increment loading images
			MXKIMAGES.loadStarted = true;
			this.hide();
			var tempImage = $("<img id='"+name+"_tmp"+this.name+"' src='' class='"+name+"' style='position:absolute; left:-5000px; top:0px'/>");
			tempImage.data("sprite", this);
			//tempImage.data("name" , name);
//			var image = $("<img id='"+name+"' src='"+data+"' style='width:100%;height:100%;' style='visibility:hidden;'/>");
			if(isIE8) {
				var image = $("<img id='"+name+"' src='"+data+"' class='sprite_image' />");
			}
			if(isIE8 && data.substring(0, 20).indexOf("png")!=-1) {
				image.css('filter', "progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled='true',sizingMethod='scale',src='" + data + "')");
			}
			if(isIE8) {
				image.hide();
				this.images[name] = image;
			} else {
				this.imageNames = []; //hack
				this.imageNames[this.imageNames.length] = name;
			}
			tempImage.load(function(self){
				if(! (isIE8||isIE7||isIE6) ) {
					loadImage( $(this), image, false, isFromSaved);
				}
			});
			tempImage.attr("src", data);
			$("body").append(tempImage);
			if((isIE8||isIE7||isIE6) ) {
				setTimeout(function() {
					loadImage( tempImage, image, true, isFromSaved);
				}, 10);
			}
		}
		
		this.spriteCount = 1;
		/**
		 * Sets number of vertically assembled sprite images inside the background image
		 * @param {Number} number of sub-images ivolved
		 */
		this.setSpriteCount	= function(spriteCount) {
			this.spriteCount = spriteCount;
			this.height = parseInt( this.imageHeight / spriteCount );
			//rescale background images
			var imageHeightRelative = (spriteCount * 100) + "%"
			for(var i in this.images) {
				this.images[i].css("height", imageHeightRelative);
			}
			var hName = "h_"+this.height;
			var classList = this.imgObj.attr('class').split(/\s+/);
			for(var i=0;i<classList.length;i++) {
				var item = classList[i]; 
				if (item.substring(0,2) == 'h_') {
					this.imgObj.removeClass(item);
				}
			}			
			MXKIMAGES.addHeightClass(hName, this.height);
			this.imgObj.addClass(hName);
			this.imgObj.css({"width":"", "height":""})
		}
		
		this.imageSet = false;
		/**
		 * Sets active image by name under which the image was registered in addImage method
		 * @param {String} name unique key name of the image
		 */
		this.setImage = function(name, force) {
			if(!this.imageSet) {
				if(name != undefined && ( name != "" || isEdit() )) {
					this.imageSet = true;
				}
			}
			if(!name) name="";
			if(!force && name == this.activeImageName)
				return;
			//register for export
			if(isEdit()) {
				var registered = false;
				for(var i in this.imageNames) {
					if(this.imageNames[i] == "") continue;
					if(this.imageNames[i] == name)
						registered = true;
				}
				if(!registered) {
					this.imageNames = []; //hack
					this.imageNames[this.imageNames.length] = name;
				}
			}
			//do the job
			if(isIE8) {
				this.diagHalf = undefined; this.diagAngle=undefined; //IE8 refresh
			
				var image = this.images[name];
				if(!image) { //take the image from the global cache
					image = MXKIMAGES.getImage(name);
					if(image == undefined){
						return;
					}
					image = image.clone(true);
					this.images[name] = image;
					this.imgObj.append(image);
				}
				this.imageWidth = image.data("width");
				this.imageHeight = image.data("height");
				this.width = image.data("width");
				this.setSpriteCount(this.spriteCount);//use proper height
	//ORIG			this.height = image.data("height");
				this.scaleTo(this.scale, true);
				this.alignHandles();
				if(this.activeImage)
					this.activeImage.hide();
				image.show();
				if($.browser.msie){
				   image.css({"visibility":"visible", "display":"block"});
				}
				this.activeImage = image;
			} else { //NEWER BROWSERS IE9+
				if(name!="") {
					var img = MXKIMAGES.imageNames[name];
					this.imageWidth = img.width;
					this.imageHeight = img.height;
					this.width = img.width;
					this.setSpriteCount(this.spriteCount);//use proper height
		//ORIG			this.height = image.data("height");
					this.scaleTo(this.scale, true);
					this.alignHandles();
					if(this.activeImageName)
						this.imgObj.removeClass(this.activeImageName)
					this.imgObj.addClass(name)
				} 
				//if(isEdit()) {
					this.activeImage = MXKIMAGES.getImage(name);
				//}
			}
			if(isH5) {
				var image = MXKIMAGES.getImage(name);
				if(image == undefined){
					return;
				}
				this.imageWidth = image.data("width");
				this.imageHeight = image.data("height");
				this.width = image.data("width");
				this.setSpriteCount(this.spriteCount);//TODO SPRITING FOR HTML5
				this.scaleTo(this.scale, true);
				this.activeImage = image;			
			}
			this.activeImageName = name;
		};
		
//		$("#animationBackground").append(this.imgObj); //default canvas key TODO this inside addCanvas
		this.imgObj.data("sprite", this);
		this.imgObj.click( function() {
			var sprite = $(this).data("sprite");
			if(!sprite.isControl && isEdit() && sprite.mode != "EDIT") {
				var index = sprite.index;
//				if(index == MXKEDITOR.activeSprite.index)
//					return false;
				MXKEDITOR.activateSprite( index );
				MXKPANE.update();
			} else if( sprite.mode == 'EDIT' && !sprite.handleClicked) {
					sprite.switchToDefaultMode();
			} else {
				sprite.onClick();
			}
			sprite.handleClicked = false;
		});
/*		this.imgObj.dblclick( function() { //double-click to load new image
			var sprite = $(this).data("sprite");
			if(isEdit()) {
				var index = sprite.index;
				MXKEDITOR.activateSprite( index );
				MXKPANE.update();
				//additionally open file dialog
				if(sprite.lastDrag != undefined && (new Date().getTime() - sprite.lastDrag > 400) ) {
					$("#sprite_image_file").click();				
				}
			} else {
				sprite.onClick();
			}
		});
*/
		this.spriteIndexApply = false;
		this.positionApply = true;
		this.angleApply = false;
		this.scaleApply = false;
		this.opacityApply = false;
		this.zIndexApply = false;
		this.visibilityApply = false;
		this.position = {top:0, left:0};
		this.angle = 0;
		this.scale = 1;
		this.opacity = 1;
		this.spriteIndex = 1;
		this.width = 217;//TODO maybe better
	    this.height = 217;
		this.imageWidth = 217;//TODO maybe better
	    this.imageHeight = 217;
		this.visibility = true;
		/**
		 * Destroys sprites visualization
		 */
		this.destroy = function() {this.imgObj.remove();}; //TODO ensure of deleting of all references
		/**
		 * Hides sprite
		 */
		this.hide = function() { this.imgObj.hide();};
		/**
		 * Shows hidden sprite
		 */
		this.show = function() { 
//			this.imgObj.show(); TODO some proprietery Firebug BUG
//			if($.browser.msie){
			   this.imgObj.css({"visibility":"visible", "display":"block"});
//			}
		};
		/**
		 * Sets sprite's opacity. Animating opacity on moving objects in JavaScript playback mode may be flickering in some older browsers.
		 * @param {Float} opacity Opacity in range 0..1
		 */
		this.fadeTo = function(opacity) {
			if(opacity == undefined || this.opacity == opacity) {
				this.opacityApply = false;
				return; //nothing to change
			}
			this.opacity = opacity;
			this.opacityApply = true;
			
		};
		/**
		 * Move sprite to specified [X,Y] position (in pixels). It is position of top-left corner of sprite relative to top-left position of hosting canvas.
		 * @param {Number} x X coodrinate (from left)
		 * @param {Number} y Y coodrinate (from top)
		 */
		this.moveTo = function(x, y) {
			if(x == undefined || y == undefined) {
				return;
			}
			if(this.position.left == x &&  this.position.top == y) {
				this.positionApply = false;
				return; //nothing to change
			}
			this.position.left = x;
			this.position.top = y;
			this.positionApply = true;
		};
		/**
		 * Move sprite relative to its previous position.
		 * @param {Number} deltaX X coodrinate increment
		 * @param {Number} deltay Y coodrinate increment
		 */
		this.move = function(deltaX, deltaY) {
			if(deltaX == 0 && deltaY == 0) {
				return; //no speed
			}
			this.moveTo( this.position.left + deltaX, this.position.top + deltaY);
		};
		/**
		 * Rotate sprite to specified angle (clockwise, in degrees) around to its center
		 * @param {Number} angle The angle
		 */
		this.rotateTo = function(angle) {
			if(angle == undefined || this.angle == angle) {
				this.angleApply = false;
				return; //nothing to change
			}
//			if(angle >= 360) {
//				this.angle = angle % 360;
//			} else {
				this.angle = angle;
//			}
			this.angleApply = true;
		};
		/**
		 * Rotate sprite relative to its previous rotation, aka: 100(prev) + 5(delta) = 105(new angle)
		 * @param {Number} angleDelta The angle delta
		 */
		this.rotate = function(angleDelta) {
			if(angleDelta == undefined || angleDelta == 0) {
				return; //nothing to change
			}
			this.rotateTo (this.angle + angleDelta );
		};
		this.zIndex = 0;
		/**
		 * Change Z coodrinate. It manages priority which layers are rendered over others. Higher Z means more visible.
		 * @param {Number} zIndex The Z coordinate value
		 */
		this.setZIndex = function(zIndex) {
			if(zIndex == undefined || this.zIndex == zIndex) {
				this.zIndexApply = false;
				return; //nothing to change
			}
			if(isNaN(zIndex))
				this.zIndex = parseInt(zIndex);
			else
				this.zIndex = zIndex;
			this.zIndexApply = true;
		};
		this.setZIndex(100); //default value
		/**
		 * Scale the sprite size. 
		 * @param {Number} ration The scale multiplicator, newSize = defaultSize * ratio.
		 */
		this.scaleTo = function(ratio, force) {
			if(ratio == undefined || ( !force && this.ratio == ratio ) ) {
				this.scaleApply = false;
				return; //nothing to change
			}
			this.scale = ratio;
			this.scaleApply = true;
		};
		this.scaleTo(0.99);//default set
		this.scaleTo(1);//default set
		
		/**
		 * Set visible sub-image of sprited layers (vertically aligned pictures in a single image file)
		 * @param {Number} spriteIndex order index of the sub-image (1..Number of images)
		 */
		this.setSpriteIndex = function(spriteIndex) {
			if(spriteIndex == undefined || this.spriteIndex == spriteIndex ) {
				this.spriteIndexApply = false;
				return; //nothing to change
			}
			this.spriteIndex = spriteIndex;
			this.spriteIndexApply = true;
		}
		/**
		 * @ignore
		 */
		this.setEasing = function(easing) {
			this.easingOrig = easing;
			this.easing = easing;
			this.easingName = undefined;
			if(easing instanceof Array) {
				this.easing = 5;
				this.easingName = "cubic-bezier";
				this.bezier = easing;
			} else {
				if(easing == 1) {
					this.easingName = "ease";
					this.bezier = [0.25,0.1,0.25,1];
				} else if(easing == 2) {
					this.easingName = "ease-in";
					this.bezier = [0.42,0,1,1];
				} else if(easing == 3) {
					this.easingName = "ease-out";
					this.bezier = [0,0,0.58,1];
				} else if(easing == 4) {
					this.easingName = "ease-in-out";
					this.bezier = [0.42,0,0.58,1];
				}
			}
			//precalculate bezier
		}
		/**
		 * @ignore
		 */
		this.setInterpolation = function(interpolation) {
			this.interpolation = interpolation;
		}

		/**
		 * @ignore
		 */
		this.setSound = function(sound) {
			this.sound = sound;
			this.soundApply = true;
		}
		
		/**
		 * Apply sprite visibility
		 * @param {Number} ratio The scale multiplicator, newSize = defaultSize * ratio.
		 */
		this.setVisibility = function(visibility) {
			if(visibility == undefined) {
					if(this.imageSet && this.visibility == false) {
						this.visibility = true;
						this.visibilityApply = true;
					} else if(!this.imageSet && this.visibility == true) {
						this.visibility = false;
						this.visibilityApply = true;
					}
					return;
			}
			if(this.visibility != visibility) {
				this.visibility = visibility;
				this.visibilityApply = true;
			}
		};
		/**
		 * Get the width resulting from last scale set
		 */
		this.getWidth = function() {
			if(this.parentSprite)
				return this.width * this.getInheritedScale();
			else 
				return this.width * this.scale;
		}
		/**
		 * Get the height resulting from last scale set
		 */
		this.getHeight = function() {
			if(this.parentSprite)
				return this.height * this.getInheritedScale();
			else 
				return this.height * this.scale;
		}
		/**
		 * @ignore
		 */
		this.getRotation = function() {
			var tr = this.imgObj.css("-webkit-transform") ||
					 this.imgObj.css("-moz-transform") ||
					 this.imgObj.css("-ms-transform") ||
					 this.imgObj.css("-o-transform") ||
					 this.imgObj.css("transform") ||
					 "fail...";
			var values = tr.split('(')[1];
				values = values.split(')')[0];
				values = values.split(',');
			var a = values[0];
			var b = values[1];
			var c = values[2];
			var d = values[3];
			var scale = Math.sqrt(a*a + b*b);
			var sin = b/scale;
			var angle = Math.round(Math.atan2(b, a) * (180/Math.PI));
			return angle;	
		}
		this.delay = 100;
		this.isRunning = false;
		/**
		 * Start animation sequence on a sprite.
		 * @param {Animation} animation  The animation to play. If not defined then the currenlty active animation is played
		 * @param {Number} playFrom Starting start time in seconds, limiting the animation sequence.
		 * @param {Number} playTo End time in seconds, limiting the animation sequence.
		 */
		this.startAnimation = function(animation, playFrom, playTo) { 
			if(playTo == 0) playTo = 0.0001;
			if(isCSS3) {
				delete runningRegistry[this.name]; //for sure
				if(this.isRunning == true) {
					this.isRunning = false;
					this.animation.reset();
					this.onAnimationStop();
					this.isStopAnimation = false;
				}
				if(animation != undefined && animation != null) {
					this.animation = animation;
				}
				this.animation.reset();
//				if(!isEdit()) {
//					this.applyFrame(this.animation.frames[0]); //TODO play from
//					this.update();
//				}
				//create keyframes if not made
//				this.animation.createCSS3( this, playFrom, playTo );
				//start CSS3 animation
				this.duration = this.animation.duration;
				if(playTo == undefined) {
					playTo = this.duration;
				}
				this.animation.setEndFrame(  playTo );
				this.duration = playTo;
				if(playFrom == undefined) {
					playFrom = 0.0;
				}
				this.animation.setFrame(  playFrom ); //TODO TIME BASED
				this.duration -= playFrom;

				this.playFrom = playFrom;
				this.playTo = playTo;
				this.isRunning = true;
				if(animation != undefined && animation != null) {
					this.animation = animation;
					if(this.animation.sprite && this.animation.sprite != this)
						alert('Error: running single animation instance on multiple sprites');
					this.animation.sprite = this;
				}
				this.animation.reset();
				if(!isEdit()) {
					this.applyFrame( this.animation.findLastDefinedTimeFrameOrInterpolate(playFrom) ); //TODO PLAY FROM
					this.update();
				}
				this.onAnimationStart();
				this.imageSet = false;
			
				if(this.isPaused) {
					this.resumeAnimation();
				}
				runningRegistry[this.name] = this;
//				this.animation.startCss3( 
//								this.animation.css3KeyframesNames[playFrom+'-'+playTo],
//								duration
//								);
//				$('#logger').append(" *start"+this.name);
				if(isAnimationLoop)
					startAnimationLoop();
			} else if(isH5) { //H5 styler
				if(this.isRunning == true) {
					delete runningRegistry[this.name];
					this.isRunning = false;
					this.animation.reset();
					this.onAnimationStop();
					this.isStopAnimation = false;
				}
				if(animation != undefined && animation != null) {
					this.animation = animation;
				}
				this.animation.reset();
/*				if(playFrom != undefined) {
					var staticIndex = this.animation.calcIndexFromTime(playFrom);
					this.animation.setFrame(  staticIndex );
				}
				if(playTo != undefined) {
					var staticIndex = this.animation.calcIndexFromTime(playTo);
					this.animation.setEndFrame(  staticIndex );
				}*/
				this.duration = this.animation.duration;
				if(playTo == undefined) {
					playTo = this.duration;
				}
				this.duration = playTo;
				if(playFrom == undefined) {
					playFrom = 0.0;
				}
				this.duration -= playFrom;
				if(playFrom != undefined) {
					var staticIndex = this.animation.calcIndexFromTime(playFrom);
					this.animation.setFrame(  staticIndex );
				}
				if(playTo != undefined) {
					var staticIndex = this.animation.calcIndexFromTime(playTo);
					this.animation.setEndFrame(  staticIndex );
				}

				this.playFrom = playFrom;
				this.playTo = playTo;
				
				this.isRunning = true;
				this.onAnimationStart();
				runningRegistry[this.name] = this;
	//			this.animate(); //TODO check if ok for repeating animations
				this.imageSet = false;
				this.animation.h5Start = 0;
//				if(isAnimationLoop)
					startAnimationLoop();
			} else { //OLD styler
				if(this.isRunning == true) {
					delete runningRegistry[this.name];
					this.isRunning = false;
					this.animation.reset();
					this.onAnimationStop();
					this.isStopAnimation = false;
				}
				if(animation != undefined && animation != null) {
					this.animation = animation;
				}
				this.animation.reset();
				
				this.duration = this.animation.duration;
				if(playTo == undefined) {
					playTo = this.duration;
				}
				this.duration = playTo;
				if(playFrom == undefined) {
					playFrom = 0.0;
				}
				this.duration -= playFrom;

				if(playFrom != undefined) {
					var staticIndex = this.animation.calcIndexFromTime(playFrom);
					this.animation.setFrame(  staticIndex );
				}
				if(playTo != undefined) {
					var staticIndex = this.animation.calcIndexFromTime(playTo);
					this.animation.setEndFrame(  staticIndex );
				}
				this.isRunning = true;
				this.onAnimationStart();
				runningRegistry[this.name] = this;
	//			this.animate(); //TODO check if ok for repeating animations
				this.imageSet = false;
				startAnimationLoop();
			}
		};
		this.isStopAnimation = false;
		/**
		 * @ignore
		 */
		this.animate = function() {
			if(this.isRunning == false) return;
			if(this.onDrawFrame != undefined)
				this.onDrawFrame();
			if(this.isStopAnimation) {
				delete runningRegistry[this.name];
				this.isRunning = false;
				this.animation.reset();
				this.onAnimationStop();
				this.isStopAnimation = false;
				return;
			}
			var isNext = this.animation.isNextFrame();
			if(!isNext) {
				delete runningRegistry[this.name];
				this.isRunning = false;
				if(isEdit() && Object.keys(runningRegistry).length == 0) {
					var lastFrame = this.animation.index-1;
					MXKEDITOR.setActiveFrame(lastFrame);
					$("#activeFrame").val(lastFrame + 1).change();
					MXKPANE.update();
				}
				this.animation.reset();
				this.finish();
				this.onAnimationEnd();
				return;
			}
			var frame = this.animation.getNextFrame();
			if(frame) {
				this.ix = ix;
				this.applyFrame(frame, true);
//				this.update();
			}  else if(this.animation.index == 1) {
				this.imageSet = false;
				this.setVisibility(); //handling empty image at animation reply
				this.ix = ix;
			}
		}
		
		/**
		 * @ignore
		 */
		this.animateH5 = function() {
			if(this.isRunning == false) return;
			if(this.onDrawFrame != undefined)
				this.onDrawFrame();
			var animation = this.animation;
			if(this.isStopAnimation) {
				delete runningRegistry[this.name];
				this.isRunning = false;
				animation.reset();
				this.onAnimationStop();
				this.isStopAnimation = false;
				if(isEdit())
					stopAnimationLoop();
				return;
			}
			if(!animation.h5Start)
				animation.h5Start = h5Clock;
			animation.h5Time = (h5Clock - animation.h5Start) / 1000; //seconds
			var isNext = animation.isNextFrameH5(); //TODO
			if(!isNext) {
				delete runningRegistry[this.name];
				this.isRunning = false;
				if(isEdit()) {
					stopAnimationLoop();
					MXKCANVAS.clearH5();
					MXKEDITOR.setActiveFrame(animation.calcTimeFromIndex(animation.endIndex));
					MXKPANE.update();
				}
/*				if(isEdit() && Object.keys(runningRegistry).length == 0) {
					var lastFrame = animation.index-1; //TODO
					MXKEDITOR.setActiveFrame(lastFrame);
					$("#activeFrame").val(lastFrame + 1).change();
					MXKPANE.update();
				}*/
				animation.reset();
				this.finish();
				this.onAnimationEnd();
				return false;
			}
			var frame = animation.getNextFrameH5();
			if(frame) {
				this.ix = ix;
				this.applyFrame(frame, true);
			}  
			return true;
		}
		
		this.audIntervals = {};
		/**
		 * @ignore
		 */
		this.css3PlaySound = function(frameA, frameT, interval) {
			var soundId = MXKSOUNDS.playSound(frameA);
//			console.log('clearing interval ' + frameA+" "+frameT);
//			clearInterval( interval );
		};
		
		/**
		 * @ignore
		 */
		this.css3AnimationStart = function(event) {
			var audIntervals = this.audIntervals;
			//go through all timeFrames in the animation and set timers for audio
			if(MXKSOUNDS.isAny) { //if there is at least one sound used
				//got through timeframes
				for(var i = 0; i < this.animation.timeFrames.length; i++) {
					var frame = this.animation.timeFrames[i];
					if(frame != undefined && frame.a && this.playFrom <= frame.t && this.playTo > frame.t) { //check for audio
//						console.log('audio ' + frame.t + " " + frame.a);
						var frameT = frame.t;
						var frameA = frame.a;
						var func = this.css3PlaySound;
						setTimeout(function() {
							func(frameA, frameT, audIntervals[frameA+" "+frameT]);
						}, (frame.t - this.playFrom) * 1000 );
//						var interval = setInterval(function() {
//							func(frameA, frameT, audIntervals[frameA+" "+frameT]);
//						}, (frame.t - delta) * 1000 );
//						this.audIntervals[frame.a+" "+frame.t] = interval;
					}
				}
				
			}
		};
		this.css3ClearAudioIntervals = function() {
			if(this.audIntervals) {
//				console.log('clearing ALL intervals');
				for(var name in this.audIntervals) {
//					console.log('clearing interval all ' + name);
					var interval = this.audIntervals[name];
					clearInterval( interval ) ;
					delete this.audIntervals[name];
				}
			}
			MXKSOUNDS.clearSounds(); //stop all sounds
		};
		/**
		 * @ignore
		 */
		this.css3AnimationEnd = function() {
			if (this.animation.isEndIndex)
				var lastFrame = this.animation.findLastDefinedTimeFrameOrInterpolate(this.animation.endIndex);//this.animation.timeFrames[this.animation.findLastDefinedTimeFrame(this.animation.endIndex)];
			else
				var lastFrame = this.animation.findLastDefinedTimeFrame(1000000);//this.animation.timeFrames[this.animation.findLastDefinedTimeFrame(1000000)];
			this.applyFrame(lastFrame);
			this.update();
			delete runningRegistry[this.name];
			this.isRunning = false;
			this.animation.reset();
			this.finish();
			this.onAnimationEnd();
		};

		/**
		 * @ignore
		 */
		this.finish = function() {
		};
		if(isCSS3) {
//			if(isOpera) {	
//				this.imgObj[0].addEventListener("animationend", function(e) {
//					var sprite = $(e.target).data("sprite");
//					sprite.css3AnimationEnd();
//					return false;
//				});
//			} else {
				this.imgObj.on('webkitAnimationEnd oanimationend msAnimationEnd animationend', function(e) {
					var sprite = $(this).data("sprite");
					sprite.css3AnimationEnd();
					return false;
				});
				this.imgObj.on('webkitAnimationStart oanimationstart msAnimationStart animationstart', function(e) {
					var sprite = $(this).data("sprite");
					sprite.css3AnimationStart(e);
					return false;
				});
//			}
		}
		
		/**
		 * Pause animation sequence on a sprite.
		 */
		this.pauseAnimation = function() { 
			delete runningRegistry[this.name];
			if(isCSS3) {
//				this.imgObj.addClass("css3Paused");
				this.imgObj.css({"animation-play-state":"paused", "-webkit-animation-play-state":"paused"});
				this.isPaused = true;
				//TODO apply the time
			} 
			
		};
		/**
		 * Pause animation sequence on a sprite.
		 */
		this.resumeAnimation = function() { 
			if(isCSS3) {
//				this.imgObj.removeClass("css3Paused");
				this.imgObj.css({"animation-play-state":"running", "-webkit-animation-play-state":"running"});
				this.isPaused = false;
			} 
			runningRegistry[this.name] = this;
		};
		
		/**
		 * @ignore
		 */
		this.findLastDefinedFrame = function(beforeThis) {
			return this.animation.findLastDefinedFrame(beforeThis);
		};

		/**
		 * Sets parent sprite. When there is a parent Sprite assigned, the position and rotation of the child Sprite is applied relative to the parent, instead of the canvas. Parent and child have still independent animation lifecycles.
		 * @param {Sprite} sprite The parent Sprite object
		 */
		this.setParentSprite = function(sprite) {
			if(!this.parentSprite && !sprite)
				return;
			if(this.parentSprite && !sprite) {
				if(!isIE8) {
					this.imgObj.detach();
					this.canvas.addSprite(this);
				}
				for(var i=0; i<sprite.children.length; i++) {
					if(sprite.children[i] == this)
						sprite.children.splice(i, 1);
				}
				this.parentSprite = undefined;
				return;
			}
			if(!isIE8) {
				this.imgObj.detach();
				sprite.imgObj.append(this.imgObj);
			} 
			sprite.children.push( this );
			
			this.parentSprite = sprite;
		}
		
		/**
		 * Ask to redraw the sprite. This must be called to apply state changes made in state method like: move..., rotate..., fade..., setZIndex... etc.
		 */
		this.update = function(idDryRun, isSound) {
//			$('#logger').append(" *update"+this.name);
			var newStyle = "";
			var spStyle = "";
			var c3Style = "";
			var dTop = 0; //IE stuff for filters
			var dLeft = 0;
			if(this.isUndo) {
				this.updateUndoBuffer(5);
 			}
			var hasParent = (this.parentSprite != undefined);
			var hasParentIE8 = hasParent && isIE8;

			if(this.spriteIndexApply || this.positionApply || this.angleApply || this.scaleApply || this.opacityApply || this.zIndexApply || this.visibilityApply || this.firstLoad || hasParentIE8 || this.soundApply) {
				var GS = this.canvas.GLOBAL_SCALE;

//				if(this.sound)
//					console.log(isSound + " " + this.playingSound + " " + this.lastPlayTime + " " +  this.sound + " " +  this.intTime );
				//sound
				if(this.sound && isSound && this.playingSound != this.sound && this.lastPlayTime != this.intTime) {
					this.playingSoundId = MXKSOUNDS.playSound(this.sound);
					this.playingSound = this.sound;
					this.sound = undefined;
					this.lastPlayTime = this.intTime;
				}
				this.soundApply = false;
				
				//opacity
				if(this.opacity != 1) {
					newStyle += "opacity:" + this.opacity + ";";
				}
				this.opacityApply = false;
				//rotation
				if(isWebKit)
					spStyle += "-webkit-transform:";
				else if(isMozilla)
					spStyle += "-moz-transform:";
				else if(isOpera)
					spStyle += "-o-transform:";
				else if(isIE9)
					spStyle += "-ms-transform:";
				if( !(isIE8 || isIE7 || isIE9))	
					c3Style += "transform:"; //for the newest or for sure
				var sX,sY,sS;
				if(GS == 1.0 || hasParent) {
					sX = this.position.left;
					sY = this.position.top;
					sS = this.scale;
				} else {
//					sX = (this.position.left * GS) + (this.getWidth()*(GS - 1.0))/2.0;
//					sY = (this.position.top * GS) + (this.getHeight()*(GS - 1.0))/2.0;
					sX = (this.position.left * GS) + (this.width*(GS - 1.0))/2.0;
					sY = (this.position.top * GS) + (this.height*(GS - 1.0))/2.0;
					sS = this.scale * GS;
				}
				if(bFeatures.canCss3D) {
//					spStyle += " rotate(" + this.angle + "deg) scale("+ this.scale +");";
//					c3Style += " rotate(" + this.angle + "deg) scale("+ this.scale +");"; //for the newest or for sure
					var stil = " translate3d(" +sX+ "px, " +sY+ "px, 0px) rotateZ(" + this.angle + "deg) scale3d("+sS+","+sS+",1);";
					spStyle += stil;
					c3Style += stil; //for the newest or for sure
				} else if(isIE9 || isOpera ) {
					spStyle += " translate(" +sX+ "px, " +sY+ "px) rotate(" + this.angle + "deg) scale("+sS+");";
				}
				//old ie stuff
				else if(isIE6 || isIE7 || isIE8) {
					if(hasParentIE8) {
						var angle = (this.getInheritedAngle() /*% 360*/);// TODO new
					} else {
						var angle = this.angle;
					}
					if(angle > 90 && angle <= 180) {
						angle = 180 - angle;
					}
					else if(angle > 180 && angle <= 270) {
						angle -= 180;
					}
					else if(angle > 270 && angle <= 360) {
						angle = 360 - angle;
					}
					
					if(hasParentIE8) {
						var rad = this.getInheritedAngle() * (Math.PI/180);
					} else {
						var rad = this.angle * (Math.PI/180);
					}
					var cos = Math.cos(rad);
					var sin = Math.sin(rad);
					if(isIE6 || isIE7) {
						newStyle += "filter: progid:DXImageTransform.Microsoft.Matrix(filtertype='bilinear', sizingMethod='auto expand', M11="+cos+", M12="+(-sin)+", M21="+sin+", M22="+cos+");";
					} else {
						newStyle += "-ms-filter: \"progid:DXImageTransform.Microsoft.Matrix(filtertype='bilinear', SizingMethod='auto expand', M11="+cos+", M12="+(-sin)+", M21="+sin+", M22="+cos+")\";";
					}
					//delta position
					rad = angle * (Math.PI/180); //kastrovany uhel
					var w = this.getWidth();
					var h = this.getHeight();
					var dHalf = Math.sqrt(w*w + h*h)/2;
					dTop = dHalf * Math.sin( Math.atan(h/w) + rad )  - (h / 2);
					dLeft = dHalf * Math.sin( Math.atan(w/h) + rad )  - (w / 2);

					//scale
					newStyle += "width:" + ( parseInt(this.width * this.scale) ) + "px; height:" + (parseInt(this.height * this.scale) ) + "px;"
	//					if(!isIE8)
	//						newStyle += "background-size:" + (parseInt( this.imageWidth * this.scale) ) + "px " + (parseInt( this.imageHeight * this.scale) ) + "px;"
				}
				this.angleApply = false;
				this.scaleApply = false;

				//z
				if(this.zIndex != 0 || hasParentIE8) {
					if(hasParentIE8) {
						newStyle += "z-index:" + this.getInheritedZIndex() + ";";
					} else {
						newStyle += "z-index:" + this.zIndex + ";";
					}
				}
				this.zIndexApply = false;
				//position
/*
				if(hasParentIE8) {
					this.getChildPosition();
					newStyle += "top:" + (this.childPosition.top - dTop) + "px; left:" + (this.childPosition.left - dLeft) + "px;"; //TODO APPLY PARENT SCALE
				} else {
					newStyle += "top:" + (this.position.top - dTop) + "px; left:" + (this.position.left - dLeft) + "px;";
				}
*/
				if(hasParentIE8) {
					this.getChildPosition();
					newStyle += "top:" + (this.childPosition.top - dTop) + "px; left:" + (this.childPosition.left - dLeft) + "px;"; //TODO APPLY PARENT SCALE
				} 
//				else {
//					newStyle += "top:" + (this.position.top - dTop) + "px; left:" + (this.position.left - dLeft) + "px;";
//				}
						
				this.positionApply = false;

/*TODO visibility				
				if(this.visibility == false) {
					newStyle += "display:none;";
					this.visibilityApply = false;
				}
*/

				//sprite image index
				if(isIE8) {
					var subStyle = "margin-top:" +(-this.height * this.spriteIndex)+ "px;"; //TODO apply to the child DIV
					this.imgObjSub.css('cssText', subStyle);
				} else { //IE9+
					newStyle += "background-position: 0px "+(-this.height * (this.spriteIndex-1))+"px;";
				}
				this.spriteIndexApply = false;

				newStyle += spStyle + c3Style;
			}
/*			
			if(this.positionApply) {
				newStyle += "top:" + this.position.top + "px; left:" + this.position.left + "px;"
				this.positionApply = false;
			}
			if(this.angleApply) {
				newStyle += "transform:(" + this.angle + "deg); -webkit-transform:(" + this.angle + "deg); -o-transform:(" + this.angle + "deg); -moz-transform:(" + this.angle + "deg); -ms-transform:(" + this.angle + "deg);";
				this.angleApply = false;
			}
			if(this.scaleApply) {
				newStyle += "width:" + (this.width * this.scale) + "px; height:" + (this.height * this.scale) + "px;"
				this.scaleApply = false;
			}
			if(this.opacityApply) {
				newStyle += "opacity:" + this.opacity + ";";
				this.opacityApply = false;
			}
			if(this.zIndexApply) {
				newStyle += "z-index:" + this.zIndex + ";";
				this.zIndexApply = false;
			}
*/
			if(idDryRun) {
				return newStyle;
			}
			if(newStyle != "") {
				this.imgObj.css('cssText', newStyle);
			}
			if(this.firstLoad) {
				this.show();
				this.firstLoad = false;
			}
			if(isIE8 && this.children.length > 0) {
				this.updateChildren();
			}
//			if(isSound) {
//				MXKSOUNDS.playSound( this.sound );
//			}
		}
		/**
		 * @ignore
		 */
		this.updateCss3Sprite = function(options) {
			if(options.p)
				return "background-position: 0px "+(-this.height * (this.spriteIndex-1))+"px;";
			return "";
		}
		/**
		 * @ignore
		 */
		this.updateCss3Easing = function() {
			//easing
			if(this.easing) {
				var timing = this.easingName;
				if(this.easing == 5) //beier
					timing += "("+this.bezier[0]+","+this.bezier[1]+","+this.bezier[2]+","+this.bezier[3]+")";
			} else {
				timing = "linear";
			}
			if(isWebKit)
				return "-webkit-animation-timing-function:"+timing+";";
			else if(isMozilla)
				return "-moz-animation-timing-function:"+timing+";";
			else
				return "animation-timing-function:"+timing+";";
		}
		/**
		 * @ignore
		 */
		this.updateCss3 = function(options) {
			var newStyle = "";
			var spStyle = "";
			var c3Style = "";
			if(this.isUndo) {
				this.updateUndoBuffer(5);
 			}
			var hasParent = (this.parentSprite != undefined);
			var hasParentIE8 = hasParent && isIE8;

			if( this.spriteIndexApply || this.positionApply || this.angleApply || this.scaleApply || this.opacityApply || this.zIndexApply || this.visibilityApply || this.firstLoad || hasParentIE8 ) {
				var GS = this.canvas.GLOBAL_SCALE;
				//opacity
				if(options.o) {
					newStyle += "opacity:" + this.opacity + ";";
				}
				this.opacityApply = false;
				//transform
				if(options.t) {
					if(isWebKit)
						spStyle += "-webkit-transform: ";
					else if(isMozilla)
						spStyle += "-moz-transform: ";
					else if(isOpera)
						spStyle += "-o-transform: ";
					else if(isIE9)
						spStyle += "-ms-transform: ";
					if( !(isIE8 || isIE7))	
						c3Style += "transform: "; //for the newest or for sure
					var sX,sY,sS;
					if(GS == 1.0 || hasParent) {
						sX = this.position.left;
						sY = this.position.top;
						sS = this.scale;
					} else {
//						sX = (this.position.left * GS) + (this.getWidth()*(GS - 1.0))/2.0;
//						sY = (this.position.top * GS) + (this.getHeight()*(GS - 1.0))/2.0;
						sX = (this.position.left * GS) + (this.width*(GS - 1.0))/2.0;
						sY = (this.position.top * GS) + (this.height*(GS - 1.0))/2.0;
						sS = this.scale * GS;
					}
					if(bFeatures.canCss3) {
						var t = "";
						t += " translate3d(" + sX + "px, " + sY + "px, 0px) ";
						t += "rotateZ(" + this.angle + "deg) ";
						t += "scale3d("+ sS +","+ sS +",1)";
						t += ";";
						spStyle += t;
						c3Style += t;//for the newest or for sure
					} else if(isIE9 || isOpera ) {
						var t = "";
						t += " translate(" + sX + "px, " + sY + "px) ";
						t += "rotate(" + this.angle + "deg) ";
						t += "scale("+ sS +")";
						t += ";";
						spStyle += t;
						c3Style += t;//for the newest or for sure
					}
					//scale
	//				newStyle += "width:" + ( parseInt(this.width * this.scale) ) + "px; height:" + (parseInt(this.height * this.scale) ) + "px;"
	//				if(!isIE8)
	//					newStyle += "background-size:" + (parseInt( this.imageWidth * this.scale) ) + "px " + (parseInt( this.imageHeight * this.scale) ) + "px;"

				}
				this.angleApply = false;
				this.scaleApply = false;
				this.positionApply = false;

				//z
				if(options.z) {
					if(hasParentIE8) {
						newStyle += "z-index:" + this.getInheritedZIndex() + ";";
					} else {
						newStyle += "z-index:" + this.zIndex + ";";
					}
				}
				this.zIndexApply = false;

//				newStyle += "top:" + (this.position.top) + "px; left:" + (this.position.left) + "px;";

//				if(isWebKit || isMozilla || isOpera || isIE9)
//					spStyle += " translate(" + this.position.left + "px, " + this.position.top + "px);";
//				else if(isIE8 || isIE7)
//					newStyle += "top:" + this.position.top + "px; left:" + this.position.left + "px;"
//				if( !(isIE8 || isIE7))	
//					c3Style += " translate(" + this.position.left + "px, " + this.position.top + "px);"; //TODO top left 0,0 to class
						

				if(options.v) {
					if(this.visibility == false) {
						newStyle += "display:none;";
	//					newStyle += "visibility:hidden;";
						this.visibilityApply = false;
					}
				}
//				this.visibilityApply = false;

				if(isIE8) { //TODO remove redundant
					var subStyle = "margin-top:" +(-this.height * this.spriteIndex)+ "px;"; //TODO apply to the child DIV
					this.imgObjSub.css('cssText', subStyle);
				} else { //IE9+
//					newStyle += "background-position: 0px "+(-this.height * (this.spriteIndex-1))+"px;";
				}
				this.spriteIndexApply = false;
				
				newStyle += spStyle + c3Style;
			}
			if(this.firstLoad) {
				this.show();
				this.firstLoad = false;
			}
			return newStyle;

		};


/////////////H5 part
		/**
		 * @ignore
		 */
		this.checkH5Redraw = function(options) {
			if( this.spriteIndexApply || this.positionApply || this.angleApply || this.scaleApply || this.opacityApply || this.zIndexApply || this.visibilityApply || this.firstLoad || this.soundApply) {
				this.canvas.isH5Redraw = true;
				return true;
			}
			return false;
		}
		
		/**
		 * @ignore
		 */
		this.updateH5 = function(isSound) {
			if(this.isUndo) {
				this.updateUndoBuffer(5);
 			}
			if(!this.canvas.isH5Redraw)
				return; //none of the sprites in this canvas are changed

//			if(this.sound)
//				console.log(isSound + " " + this.playingSound + " " + this.lastPlayTime + " " +  this.sound + " " +  this.intTime + " " + this.soundStop );
			//sound
			if(this.sound && isSound && this.playingSound != this.sound && this.lastPlayTime != this.intTime) {
//				if(this.soundStop) {
//					this.soundStop = false;
//				} else {
					this.playingSoundId = MXKSOUNDS.playSound(this.sound);
					this.playingSound = this.sound;
					this.sound = undefined;
					this.lastPlayTime = this.intTime;
//				}
			}
			
			var GS = this.canvas.GLOBAL_SCALE; //responsive
			var hasParent = (this.parentSprite != undefined);

//TODO optimisation			if( this.spriteIndexApply || this.positionApply || this.angleApply || this.scaleApply || this.opacityApply || this.zIndexApply || this.visibilityApply || this.firstLoad ) {
				

				var ctx = this.canvas.canvasH5[0].getContext('2d');
				ctx.save();
				ctx.webkitImageSmoothingEnabled = true;				
				ctx.mozImageSmoothingEnabled = true;
				
				var height = this.getHeight(); //scale applied
				var width = this.getWidth(); //scale applied
				if(hasParent) {
					var rot = toRad(this.getInheritedAngle());
					ctx.globalAlpha = this.getInheritedOpacity();
					this.getCenter();
					ctx.translate( this.center.left * GS, this.center.top * GS);
					ctx.rotate( rot );
				} else {
					ctx.globalAlpha = this.opacity;
					ctx.translate(( this.position.left + this.width/2 ) * GS, (this.position.top + this.height/2) * GS);
//					ctx.translate(this.position.left + width/2, this.position.top + height/2);
					ctx.rotate( toRad(this.angle) );
				}
				if(this.spriteCount > 1)
					ctx.drawImage(this.activeImage[0], 0, (this.spriteIndex-1)*this.height, this.width, this.height, (-width*GS) / 2, (-height*GS) / 2, width*GS, height*GS);
				else
					ctx.drawImage(this.activeImage[0], -width*GS/2, -height*GS/2, width*GS, height*GS);
				ctx.restore();
			
				this.opacityApply = false;
				this.angleApply = false;
				this.scaleApply = false;
				this.positionApply = false;
				this.zIndexApply = false;
				this.visibilityApply =false;
				this.spriteIndexApply = false;
				this.soundApply = false;
//			}
			if(this.firstLoad) { //TODO?
				this.firstLoad = false;
			}
			
			if(this.children.length) {
				sortH5(this.children);
				for(var i in this.children) {
					this.children[i].updateH5(true);
				}
			}
			
		};
////////////		
		
		
		/**
		 * Ask to apply certain animation frame. Requires explicit call to "update()" method. (frames of an animation are stored in MxkAnimation.frames - JS static frame and MxkAnimation.timeFrames - time tagged original frames)
		 * @param {Object} frame The animation keyframe containg sprite state attributes
		 */
		this.applyFrame = function(f, isSound) {
			if(f) {
				this.moveTo(f.x, f.y); //x,y
				this.rotateTo(f.r); //r - rotation
				this.scaleTo(f.s); //s - scale
//				if(f.i)
//					this.setImage(f.i); //i - image
				this.setZIndex(f.z); //i - image
				this.fadeTo(f.o); //i - image
				this.setVisibility(f.v); //v - visibility
				this.setSpriteIndex(f.p); //p - picture index
				this.setEasing(f.e); //e - easing
				//just for editor
				this.setInterpolation(f.b);
				if(isSound)
					this.setSound(f.a);
				this.ft = f.t;
				this.intTime = f.intTime;
			}
//MOVED			this.update();
		};
		
		/**
		 * Force stop running animation sequence
		 */
		this.stopAnimation = function() {
			if(this.isRunning == true) {
				this.isStopAnimation = true;
			}
			//TODO inproper implementation (CSS3, sounds etc.)
		};
		
		/**
		 * @ignore
		 * todo move to editor
		 */
		this.resetSpriteToPrevious = function(frameTime) {
			var frameIndex = this.animation.findTimeFrameIndexByTime(frameTime); //TODO new method TIME
			if(frameIndex == 0) {
				//TODO reset to default frame
				return;
			}
			var sourceFrameIndex = this.animation.findLastDefinedTimeFrame(frameTime);
			if(sourceFrameIndex > -1) {
				this.copyTimeFrame(sourceFrameIndex, frameIndex, frameTime);
			}
			//project to pane
			MXKPANE.update();
		};
		
		/**
		 * @ignore
		 */
		this.copyTimeFrame = function(sourceFrameIndex, frameIndex, frameTime) { //a private method for copying frames
			var sourceFrame = this.animation.timeFrames[sourceFrameIndex];
			var targetFrame = {x : sourceFrame.x, y : sourceFrame.y, z : sourceFrame.z, i : sourceFrame.i, s : sourceFrame.s, r : sourceFrame.r, b : sourceFrame.b, p : sourceFrame.p, e : sourceFrame.e, t:frameTime};
			this.animation.fillTimeFrame(targetFrame);
//			this.animation.frames[frameIndex] = targetFrame;
			this.addToUndoBuffer(targetFrame); //todo should be merged as a setAnimationFrame(index, frame)
			//project to pane
			MXKPANE.update();
		}
		
		
		/**
		 * Handler called at the beginning of rendering of each animation keyframe
		 */
		this.onDrawFrame = undefined/*function() {}*/;
		/**
		 * Handler called at the beginning of an animation sequence execution
		 */
		this.onAnimationStart = function() {};
		/**
		 * Handler called at the end of an animation sequence execution.
		 */
		this.onAnimationEnd = function() {};
		/**
		 * Handler called at the foced stop of an animation sequence execution.
		 */
		this.onAnimationStop = function() {};
		/**
		 * Handler called upon clicking the sprite
		 */
		this.onClick = function() { };
		/**
		 * Handler called upon start of mouse hovering above sprite
		 */
		this.hoverStart = function() { };
		/**
		 * Handler called upon end of mouse hovering above sprite
		 */
		this.hoverEnd = function() { };
//		this.imgObj.click(this.onClick);
		this.imgObj.hover(function() {
			$(this).data("sprite").hoverStart();
		},
		function() {
			$(this).data("sprite").hoverEnd();
		});
		spriteRegistry[name] = this;
		spriteRegistryH5.push( this );
		//for sure
		this.scaleTo(1);
		//EDIT MODE
		this.dragStartDistance = 0;
		this.dragCenterX = 0;
		this.dragCenterY = 0;
		this.dragStartAngle = 0;
		this.dragStartScale = 0;
		this.dragStartX = 0;
		this.dragStartY = 0;
		/**
		 * @ignore
		 */
		this.alignHandles = function() {
			if(this.scaleHandle) {
				this.scaleHandle.css("left", (this.width - 15)+"px");
				this.scaleHandle.css("top", (this.height - 15)+"px");
				this.scaleHandle.css("transform", "scale("+(1/this.getInheritedScale())+")");
				this.positionHandle.css("left", ((this.width)/2 - 15)+"px");
				this.positionHandle.css("top", ((this.height)/2 - 15)+"px");
				this.positionHandle.css("transform", "scale("+(1/this.getInheritedScale())+")");
				this.rotationHandle.css("transform", "scale("+(1/this.getInheritedScale())+")");
			}
		};
		this.undoBuffer = [];
		/**
		 * @ignore
		 */
		this.updateUndoBuffer = function(undoSize) {
			var startIndex = 0;
			if(this.undoBuffer != undefined) { //uz existuje tak ho rozisrim
				var newUndoBuffer = new Array( this.animation.timeFrames.length );
				for(i = 0; i < this.undoBuffer.length; i++) {
					newUndoBuffer[i] = this.undoBuffer[i];
				}
				startIndex = this.undoBuffer.length;
				this.undoBuffer = newUndoBuffer;
			} else {
				this.undoBuffer = new Array( this.animation.timeFrames.length );
			}
			for(i = startIndex; i < this.undoBuffer.length; i++) {
					this.undoBuffer[i] = new Array( undoSize );
					this.undoBuffer[i][0] = 1; //the default undo index
			}
		};
//		if(isUndo == undefined) {
			this.isUndo = false;
//		} else {
//			this.isUndo = isUndo;
//		}
		if(this.isUndo)
			this.updateUndoBuffer(this.animation.frames.length, 5);
		//project given frame state into undo buffer
		/**
		 * @ignore
		 * TODO TIME REDESIGN CHECK
		 */
		this.addToUndoBuffer = function(frame) {
			this.updateUndoBuffer(5); //for sure
			var index = this.animation.findTimeFrameIndexByTime(frame.t);		
			var buffer = this.undoBuffer[index];
			var undoIndex = buffer[0]; //1 is default
			if(undoIndex == 1) {
				for(var i=buffer.length-1; i>1; i--) {
					buffer[i] = buffer[i-1];
				}
				buffer[1] = frame;
				return;
			} 

			if(undoIndex > 1) { //non default undo index (should be ELSE but behaves SHIT)
				var delta = undoIndex - 2;
				for(var j=undoIndex; j<buffer.length; j++) {
					buffer[j-delta] = buffer[j]; //TODO trace this
					if(j >= buffer.length - delta)
						buffer[j] = undefined;
				}
				buffer[0] = 1;
				buffer[1] = frame;
			}
		};
		/**
		 * @ignore
		 * TODO TIME REDESIGN CHECK
		 */
		this.undo = function(time) { //single step undo on given frame
			var index = this.animation.findTimeFrameIndexByTime(time);
			var buffer = this.undoBuffer[index];
			var undoIndex = buffer[0]; //1 is default for undoIndex
			if(undoIndex == buffer.length - 1 || buffer[undoIndex+1] == undefined) return false; //at the end
			undoIndex = ++buffer[0];
			var frame = buffer[undoIndex];
			if(frame) {
				frame.t = time; //for sure
				this.animation.fillTimeFrame(frame);
//				this.animation.fillFrame(index, frame);
//				this.animation.frames[index] = frame;
				return true;
			}
			return false;
		};
		/**
		 * @ignore
		 * TODO TIME REDESIGN CHECK
		 */
		this.redo = function(time) { //single step redo on given frame
			var index = this.animation.findTimeFrameIndexByTime(time);
			var buffer = this.undoBuffer[index];
			var undoIndex = buffer[0]; //1 is default for undoIndex
			if(undoIndex == 1) return false;
			undoIndex = --buffer[0];
			var frame = buffer[undoIndex];
			if(frame) {
				frame.t = time; //for sure
				this.animation.fillTimeFrame(frame);
//				this.animation.fillFrame(index, frame);
				return true;
			}
		};
		//set the default image(no_image)
		if( isEdit() && !MXKEDITOR.isLoading) {
			this.setDefaultImage("");
		}
		
		//ie8 extensions
		this.children = [];
		 /**
		 * @ignore
		 */
		this.updateChildren = function() { //refresh all children that are not animated
			var ch;
			for(i=0;i<this.children.length;i++) {
				ch = this.children[i];
				if(ch.ix != ix) {//check if the animation is really NOT running
					ch.update();
				}
			}
		}
		 /**
		 * @ignore
		 */
		this.getInheritedPositionH5 = function() {
			if(this.parentSprite) {
				var parentPos = this.parentSprite.getInheritedPositionH5(); //coordinates origin of parent
				var parentRot = toRad( this.parentSprite.getInheritedAngle() );
				
			} else {
				return this.position;
			}
		};

		/**
		 * @ignore
		 */
		this.getInheritedZIndex = function() {
			return ( (this.zIndex != undefined) ? parseInt(this.zIndex) : 0 ) + ( (this.parentSprite != undefined) ? this.parentSprite.getInheritedZIndex() : 0 );
		};
		 /**
		 * @ignore
		 */
		this.getInheritedAngle = function() {
			this.inheritedAngle = this.angle + ( (this.parentSprite != undefined) ? this.parentSprite.getInheritedAngle() : 0 );
			return this.inheritedAngle;
		};
		 /**
		 * @ignore
		 */
		this.getInheritedOpacity = function() {
			return this.opacity * ( (this.parentSprite != undefined) ? this.parentSprite.getInheritedOpacity() : 1 );
		};
		 /**
		 * @ignore
		 */
		this.getInheritedScale = function() {
			return this.scale * ( (this.parentSprite != undefined) ? this.parentSprite.getInheritedScale() : 1 );
		};
		 /**
		 * @ignore
		 */
		this.getDiagonalHalf = function() {
			if(!this.diagHalf) {
				this.diagHalf = Math.sqrt(this.width*this.width + this.height*this.height) / 2;
			}
			return this.diagHalf;
		};
		 /**
		 * @ignore
		 */
		this.getDiagonalAngleRad = function() {
			if(!this.diagAngle) {
				this.diagAngle = Math.atan( this.height / this.width );
			}
			return this.diagAngle;
		};

		this.center = {}; //HTML5 absoute translationcenter
		 /**
		 * @ignore
		 */
		this.getCenter = function() {
			if(!this.parentSprite) {
//o				this.center.top = this.position.top + this.getHeight()/2;
//o				this.center.left = this.position.left + this.getWidth()/2;
				this.center.top = this.position.top + this.height/2;
				this.center.left = this.position.left + this.width/2;
				return this.center;
			}
//			var GS = this.canvas.GLOBAL_SCALE; //responsive
			var parCenter = this.parentSprite.getCenter();
			var parScale = this.parentSprite.getInheritedScale();// * GS;
//			var w2 = this.width / 2;
//			var h2 = this.height / 2;
			var w2 = this.width * parScale / 2;
			var h2 = this.height * parScale / 2;
//			var parW2 = this.parentSprite.width/2;
//			var parH2 = this.parentSprite.height/2;
			var parW2 = this.parentSprite.getWidth()/2;
			var parH2 = this.parentSprite.getHeight()/2;
			var parAngle = this.parentSprite.getInheritedAngle();
			var parRot = toRad( parAngle );
			var parSin = Math.sin( parRot );
			var parCos = Math.cos( parRot );
			
			var scale = this.getInheritedScale()//; * GS;
			
			this.center.top = parCenter.top + parCos * ( -parH2 + h2 + this.position.top * parScale ) + parSin * ( -parW2 + w2 + this.position.left * parScale );
			this.center.left = parCenter.left - parSin * ( -parH2 + h2 + this.position.top * parScale ) + parCos * ( -parW2 + w2 + this.position.left * parScale );
			return this.center;
		};
		
		 /**
		 * @ignore
		 */
		this.getChildPosition = function() {
			if(!this.childPosition) this.childPosition = {top:this.position.top,left:this.position.left};
			if(!this.parentSprite) {
				this.childPosition.top = this.position.top;
				this.childPosition.left = this.position.left
				return;
			}
			//1. get parent position
			this.parentSprite.getChildPosition();
			var x = this.parentSprite.childPosition.left;
			var y = this.parentSprite.childPosition.top;
			var d = this.parentSprite.getDiagonalHalf();
			var B = this.parentSprite.getDiagonalAngleRad();
			var A = toRad( this.parentSprite.getInheritedAngle() );
			x += Math.cos(B) * d - Math.cos(A+B) * d;//done position of parent after full rotation
			y += Math.sin(B) * d - Math.sin(A+B) * d;

			//2. relative position of child in rotated world
			x += Math.cos(A) * this.position.left - Math.sin(A) * this.position.top;
			y += Math.sin(A) * this.position.left + Math.cos(A) * this.position.top;
			
			if(isIE8) {
				//3. unrotated position to apply
				var d = this.getDiagonalHalf();
				var B = this.getDiagonalAngleRad();
				x += Math.cos(A+B) * d - Math.cos(B) * d;
				y += Math.sin(A+B) * d - Math.sin(B) * d; //done unrotated starting position
			} 
			
			this.childPosition.top = y;
			this.childPosition.left = x;
		}
	};
	
	/**
	 * @class Represent predefined animation sequence. A keyframe in an animation is a set of sprite state attributes like position, image etc. A sprite is being assigned single animation sequence at a given time. There is a default Animation object assigned to a Sprite, taht can be manipulated through the Sprite object.
	 * @param {Number} duration initial duration of the animation in seconds
	 */
	function MxkAnimation(duration) {
		this.fps = FPS;
		this.duration = duration;
		this.numOfFrames = 0;
		this.frames = new Array();
		this.timeFrames = new Array(); //NEW TIME FRAMES
		this.framesInterpolated = new Array(); //TODO control the size to copy the size of frames array
		this.time = 0.0; //NEW TIMING VARIABLE TRANSFORMED INTO index
		this.index = 0;
		this.endIndex = 0;
		this.isEndIndex = false;
		/**
		 * @ignore
		 * Changes the size of the animation sequence buffer. The old school buffer.
		 * @param {Number} numOfFrames The size of the animation sequence
		 */
		this.setNumOfFrames = function(numOfFrames) {
			this.numOfFrames = numOfFrames;
			var tempFrames = new Array(numOfFrames);
			for(var i in this.frames) { //COPY frames
				if(i < tempFrames.length)
					tempFrames[i] = this.frames[i];
				else
					break;
			}
			this.frames = tempFrames;
			
		}
		/**
		 * @ignore
		 */
		this.isNextFrameH5 = function() {
			if(this.framesInterpolated.length == 0) return false;
			if(this.isEndIndex && this.calcIndexFromTime(this.h5Time) > this.endIndex) return false; //playFromTo
			if(this.calcIndexFromTime(this.h5Time) > this.framesInterpolated.length) return false; //TODO numOfFrames
			return true;
		}
		/**
		 * @ignore
		 */
		this.isNextFrame = function() {
			if(this.framesInterpolated.length == 0) return false;
			if(this.index > this.framesInterpolated.length) return false; //TODO numOfFrames
			if(this.isEndIndex && this.index > this.endIndex) return false;
			return true;
		}
		/**
		 * @ignore
		 */
		this.getNextFrameH5 = function() {
//			console.log('animate h5 ' + this.h5Time );
			var frame = this.findLastDefinedTimeFrameOrInterpolate( this.h5Time ); //TODO TEST AND FINE TUNE
//			if(frame)
//				var next = this.framesInterpolated[frame.iix + 1]; //next frame
			return frame;
		};
		/**
		 * @ignore
		 */
		this.getNextFrame = function() {
			var frame = this.framesInterpolated[this.index];
			this.index++;
			return frame;
		};
		/**
		 * @ignore
		 */
		this.setFrame = function(index) {
			this.index = index;
		};
		/**
		 * @ignore
		 */
		this.setEndFrame = function(index) {
			this.endIndex = index;
			this.isEndIndex = true;
		};
		/**
		 * @ignore
		 */
		this.reset = function() {
			if(isCSS3) {
				this.sprite.imgObj.css({"animation":"", "animation-name":"", "animation-duration":"", "animation-timing-function":"",
				"-webkit-animation":"", "-webkit-animation-name":"", "-webkit-animation-duration":"", "-webkit-animation-timing-function":""});					
				this.sprite.imgObj.redraw();
//				this.sprite.css3ClearAudioIntervals();
			} else {
				this.index = 0;
				this.isEndIndex = false;
				if(this.sprite.playingSound && this.sprite.playingSoundId)
					MXKSOUNDS.clearSound(document.getElementById(this.sprite.playingSoundId));
				this.sprite.soundStop = true;
				this.sprite.playingSound = undefined;
				this.sprite.sound = undefined;
				this.sprite.lastPlayTime = undefined;
				this.sprite.intTime = undefined;
				this.sprite.ft = undefined;
//				console.log('Reset called');
			}
		};
		
		var frameCounter = 0;
		/**
		 * Put keyframe definition into the animation
		 * @param {Number} index  The index to place the frame
		 * @param {Object} frame The keyframe object containig sprite state attributes
		 */
		this.fillTimeFrame = function(frame) {
			if(frame.t == undefined || frame.t == null) {
				alert('key-frame TIMESTAMP not specified');
				return false; 
			}
			if(frame.e) {
				if(frame.e == 1) {
					frame.e = [0.25,0.1,0.25,1]; //ease
				} else if(frame.e == 2) {
					frame.e = [0.42,0,1,1]; //in
				} else if(frame.e == 3) {
					frame.e = [0,0,0.58,1]; //out
				} else if(frame.e == 4) {
					frame.e = [0.42,0,0.58,1]; //inout
				}
				preCalcBez(frame.e);
			}
			var index = this.findTimeFrameIndexByTime(frame.t);
			if(index == null) {
				frame.id = frameCounter++;
				this.timeFrames[this.timeFrames.length] = frame;
			} else {
				if(isEdit()) {
					var tag = this.timeFrames[index].tag;
					frame.tag = tag;
				}
				this.timeFrames[index] = frame;
			}
			
			var staticIndex = this.calcIndexFromTime(frame.t); 
			
			this.sortTimeFrames();
			//call previous implementation
			this.fillFrame(staticIndex, frame);
			//apply first frame
			if(frame.t == 0.0 && this.sprite) {
				this.sprite.applyFrame(frame);
			}
		}
		
		/**
		 * @ignore
		 * Bubble sort of timeFrames to help CSS3 generation
		 */
		this.sortTimeFrames = function() {
			var array = [];
			for(var i = 0; i < this.timeFrames.length; i++) {
				var frame = this.timeFrames[i];
				if(frame != undefined) {
						array[array.length] = frame;
				}
			}
			
			for (var i = 0; i < array.length - 1; i++) {
				for (var j = 0; j < array.length - i - 1; j++) {
					if(array[j].t > array[j+1].t){
						var tmp = array[j];
						array[j] = array[j+1];
						array[j+1] = tmp;
					}
				}
			}			
			this.timeFrames = array;
		}
		 
		 /**
		 * @ignore
		 */
		this.calcIndexFromTime = function(time) {
			return parseInt( time * this.fps ); //TODO optimize rounding (beware up at the end position ...setDuraiton)
		}
		 /**
		 * @ignore
		 */
		this.calcTimeFromIndex = function(index) {
			return parseInt( index / this.fps ); //TODO optimize rounding (beware up at the end position ...setDuraiton)
		}
		
		 /**
		 * @ignore
		 */
		this.updateTimeFrameTime = function(oldTime, newTime) {
			var staticIndex = this.calcIndexFromTime(oldTime);
			this.deleteFrame(staticIndex);

			var i = this.findTimeFrameIndexByTime(oldTime);
			this.timeFrames[i].t = newTime;			

			var staticIndex2 = this.calcIndexFromTime(newTime); 
			this.fillFrame(staticIndex2, this.timeFrames[i]);

			this.sortTimeFrames();
		}
		
		
		/**
		 * Set duration of the animation in seconds
		 */
		this.setDuration = function(duration) {
			this.duration = duration;
			var numOfFrames = parseInt (this.duration * this.fps);
			this.setNumOfFrames(numOfFrames);
			this.refreshInterpolations();
		}

		/**
		 * @ignore
		 * Put kayframe definition at desired index position
		 * @param {Number} index  The index to place the frame
		 * @param {Object} frame The keyframe object containig sprite state attributes
		 */
		this.fillFrame = function(index, frame) {
			this.frames[index] = frame;
			this.refreshInterpolations();
		}
		
		/**
		 * @ignore TODO move to editor
		 */
		this.exportTimeFrames = function() {
			var exportFrames = [];
			for(var i = 0; i < this.timeFrames.length; i++) {
				var frame = this.timeFrames[i]
				if(frame) {
					var newFrame = { t: frame.t, x : frame.x, y : frame.y, r : frame.r, s : frame.s, z : frame.z, o : frame.o, b : frame.b, p : frame.p, e : frame.e, a : frame.a};
					exportFrames[exportFrames.length] = newFrame;
				}
			}
			return exportFrames;
		}

		/**
		 * Replace current animation sequence with a set of new time-frames
		 * @param {Array} newFrames New animation sequence
		 */
		this.fillTimeFrames = function(newFrames) {
			for(var i=0; i<newFrames.length; i++) {
				if(newFrames[i])
					this.fillTimeFrame( newFrames[i] );
			}
		}
		/**
		 * Replace current animation sequence with a set of new frames
		 * @param {Array} newFrames New animation sequence
		 */
		this.fillFrames = function(newFrames) {
			this.frames = newFrames;
			this.refreshInterpolations();
		}
		
		/**
		 * @ignore
		 */
		this.findLastDefinedTimeFrameOrInterpolate = function(beforeThisTime) {
			var intFrame = this.framesInterpolated[ this.calcIndexFromTime(beforeThisTime) ];
			if(intFrame) {
				return intFrame;
			}
			return this.timeFrames[this.findLastDefinedTimeFrame(beforeThisTime)];
		}

		
		/**
		 * @ignore
		 */
		this.findLastDefinedTimeFrame = function(beforeThisTime) {
			if(beforeThisTime == 0.0)
				return -1; //when deleted first frame
			var maxTime = 0.0;
			var maxIndex = 0;
			for(var i = 0; i < this.timeFrames.length; i++) {
				var frame = this.timeFrames[i]
				if(frame != undefined) {
					if(frame.t <= beforeThisTime && frame.t >= maxTime) {
						matTime = frame.t;
						maxIndex = i;
					}
				}
			}
			
			return maxIndex; 
		};
		
		/**
		 * @ignore
		 */
		this.findTimeFrameByTime = function(frameTime) {
			var i = this.findTimeFrameIndexByTime(frameTime);
			return this.timeFrames[i];
		}
		
		/**
		 * @ignore
		 */
		this.findTimeFrameInInterval = function(from, to, isMin) {
			if(isMin) {
				var minTime = 10000.0;
				var minIndex = 0;
				for(var i = 0; i < this.timeFrames.length; i++) {
					var frame = this.timeFrames[i]
					if(frame != undefined) {
						if(frame.t > from && frame.t < minTime && frame.t < to) {
							minTime = frame.t;
							minIndex = i;
						}
					}
				}
				if(minTime == 10000.0)
					return null;
				return this.timeFrames[minIndex];
			} else { //is MAX
				var maxTime = -1.0;
				var maxIndex = 0;
				for(var i = 0; i < this.timeFrames.length; i++) {
					var frame = this.timeFrames[i]
					if(frame != undefined) {
						if(frame.t > from && frame.t > maxTime && frame.t < to) {
							maxTime = frame.t;
							maxIndex = i;
						}
					}
				}
				if(maxTime == -1.0)
					return null;
				return this.timeFrames[maxIndex];
			}
			return null;
		}
		
		/**
		 * @ignore
		 */
		this.findTimeFrameIndexByTime = function(frameTime) {
			for(var i=0; i < this.timeFrames.length; i++) {
				if(this.timeFrames[i] != undefined && this.timeFrames[i].t == frameTime) {
					return i;
				}
			}
			return null;
		};

		/**
		 * @ignore
		 */
		this.findLastDefinedFrame = function(beforeThis) {
			for(var i = beforeThis; i >= 0; i--) {
				if(this.frames[i] != undefined) {
					return i;
				}
			}
			return -1; //when deleted first frame
		};
		
		/**
		 * @ignore
		 * dletes static frame
		 */
		this.deleteFrame = function(frameIndex) {
			this.frames[frameIndex] = undefined; //TODO TEST
		}
		/**
		 * @ignore
		 */
		this.deleteTimeFrame = function(frameTime) {
			var i = this.findTimeFrameIndexByTime(frameTime);
			if(this.timeFrames[i].tag != undefined) {
				this.timeFrames[i].tag.remove();
				this.timeFrames[i].tag = undefined;
			}
			this.timeFrames[i] = undefined;
			//remove static and interpolated frames
			var staticIndex = this.calcIndexFromTime(frameTime); //TODO conditional if static is supported
			this.deleteFrame(staticIndex);
			this.refreshInterpolations();
		}
		
		/**
		 * @ignore
		 * TODO applies only for NON-CSS3 transitions
		 */
		this.refreshInterpolations = function() {
			for(var i = 0; i < this.frames.length; i++) {
				var frame = this.frames[i];
				if(i == 0) 
					this.framesInterpolated[i] = frame;
				if( frame != undefined) {
					frame.intTime = frame.t;
					if(frame.b == 1 ) {//interpolation set from previous frame (b as BIND)
						//najdi posledni definovany prednim a proved postupnou interpolaci X,Y,Z,R,S
						var lastIndex = this.findLastDefinedFrame(i-1);
						if(lastIndex == -1)
							continue;;
						var lastFrame = this.frames[lastIndex];
						var delta = i - lastIndex;
						var deltaInv = 1 / delta;	
						if(frame.x != undefined)
							var dX = (frame.x - lastFrame.x);
						if(frame.y != undefined)
							var dY = (frame.y - lastFrame.y);
						if(frame.z != undefined)
							var dZ = (frame.z - lastFrame.z);
						if(frame.r != undefined)
							var dR = (frame.r - lastFrame.r);
						if(frame.s != undefined)
							var dS = (frame.s - lastFrame.s);
						if(frame.o != undefined)
							var dO = (frame.o - lastFrame.o);
/*
						if(frame.x != undefined)
							var rX = (frame.x - lastFrame.x) / delta;
						if(frame.y != undefined)
							var rY = (frame.y - lastFrame.y) / delta;
						if(frame.z != undefined)
							var rZ = (frame.z - lastFrame.z) / delta;
						if(frame.r != undefined)
							var rR = (frame.r - lastFrame.r) / delta;
						if(frame.s != undefined)
							var rS = (frame.s - lastFrame.s) / delta;
						if(frame.o != undefined)
							var rO = (frame.o - lastFrame.o) / delta;
*/
						var mul = 1;
						var d = 0;
						for(var j = lastIndex + 1; j < i; j++) {
							var rate = d * deltaInv;
							d++;
							if(frame.e)
								rate = getBY(frame.e[0],frame.e[1],frame.e[2],frame.e[3], rate);
//								rate = Math.pow( cubicBezier( [frame.e[0],frame.e[1]], [frame.e[2],frame.e[3]], rate)[1], 6);
//								rate = cubicBezier( [frame.e[0],frame.e[1]], [frame.e[2],frame.e[3]], rate)[1];

							frame = {
								"x": (dX == undefined)? undefined : lastFrame.x + rate * dX,
								"y": (dY == undefined)? undefined : lastFrame.y + rate * dY,
								"z": (dZ == undefined)? undefined : parseInt( lastFrame.z + rate * dZ ),
								"r": (dR == undefined)? undefined : lastFrame.r + rate * dR,
								"s": (dS == undefined)? undefined : lastFrame.s + rate * dS,
								"o": (dO == undefined)? undefined : lastFrame.o + rate * dO,
								"p": lastFrame.p,
								"b": frame.b,
								"e": frame.e,
								"a": lastFrame.a,
								"intTime" : lastFrame.t
 							};
							frame.iix = j;
							this.framesInterpolated[j] = frame;
							mul++;
						}
					} else { //no interpolation then clear
						var lastIndex = this.findLastDefinedFrame(i-1);
						for(var j = lastIndex + 1; j < i; j++) {
							var lastFrame = this.frames[lastIndex];
							this.framesInterpolated[j] = lastFrame;
						}
					}
				}
				var f = frame;
				if(f)
					f.iix = i;
				this.framesInterpolated[i] = this.frames[i];
			}
			//clear from the end
			for(var i = this.frames.length-1; i>0; i--) {
				if(this.frames[i] != undefined)
					break;
				this.framesInterpolated[i] = undefined;
			}
		}

		this.css3Keyframes = "";
		this.css3KeyframesName = "";
		this.css3KeyframesNames = [];
		this.css3KeyframesBodies = [];
		 /**
		 * @ignore
		 */
		this.createCSS3 = function(sprite, fromTime, toTime, force) { //todo sprite as an attribute of Animation
			var scaleStamp = parseInt(sprite.canvas.GLOBAL_SCALE * 100);
			var timeKey = fromTime+'-'+toTime + "-" + scaleStamp;
			if(!force && !isOpera) { //opera cannot reassign same animation twice, may overhaul HEAD with styles
				if( this.css3KeyframesNames[timeKey] )
					return;
			} 
			this.css3KeyframesName = "anim"+sprite.name+"c"+css3Counter+"cx"+scaleStamp;
			this.css3KeyframesNames[timeKey] = this.css3KeyframesName;
			css3Counter++;
			var bp = "";
			if(isWebKit)
				bp = "-webkit-";
			var head = "@"+bp+"keyframes " + this.css3KeyframesName + " {\n\t"; //head is extracted from k1 and k
			if( isOpera && !force ) {
				var body = this.css3KeyframesBodies[timeKey];
				if( body ) {
					this.css3Keyframes = head + body;
					if(isEdit() && this.styleBlock) { //duplicate code form the end for simplicity
						this.styleBlock.remove();
					}
					this.styleBlock = $("<style type='text/css'>"+this.css3Keyframes+"</style>").appendTo("head"); //duplicate code form the end for simplicity
					return;
				}
			}
			var k1 = "";
			var k = "";
			//go time frame by time frame and create keyframes, calculate percentage
			var minTime = 10000.0;
			var minIndex = 0;
			var maxTime = 0.0;
			var maxIndex = 0;
			var prevStyle = null;
			var prevStyle1 = null;
			var prevStyle2 = null;
			var prevFrame = null;
			
			if(fromTime == undefined) fromTime = 0.0;
			if(toTime == undefined) toTime = this.duration;
			
			//check updated properties
			var options = {};
			var prevF = null;
			for(var i=0; i < this.timeFrames.length; i++) {
				var frame = this.timeFrames[i];
				if(frame != undefined && frame.t >= fromTime && frame.t <= toTime ) {
					if( !prevF )
						prevF = frame;
					else {
						if( prevF.x != frame.x || prevF.y != frame.y )
							options.t = true;
						if( prevF.r != frame.r )
							options.t = true;
						if( prevF.s != frame.s )
							options.t = true;
						if( prevF.z != frame.z )
							options.z = true;
						if( prevF.o != frame.o )
							options.o = true;
						if( prevF.v != frame.v )
							options.v = true;
						if( prevF.p != frame.p )
							options.p = true;
					}
				}
			}

			for(var i=0; i < this.timeFrames.length; i++) {
				var f = "";
				var frame = this.timeFrames[i];
				if(frame != undefined && frame.t >= fromTime && frame.t <= toTime ) {
					var nextFrame = this.timeFrames[i+1];
					var percent = (frame.t - fromTime) / (toTime - fromTime);
					percent = Math.round(percent * 10000.0) / 100.0;
					f += percent+"% {\n\t";
					sprite.applyFrame(frame);
					var style = sprite.updateCss3(options);
					var style1 = sprite.updateCss3Sprite(options);
					var style2 = "";
					if(nextFrame) {
						sprite.applyFrame(nextFrame);
						var style2 = sprite.updateCss3Easing(); 
					}
					f += style + style1 + style2;
					f += "}\n";
					if(frame.t > maxTime) {
						maxTime = frame.t;
						maxIndex = i;
					}
					if(frame.t < minTime) {
						minTime = frame.t;
						minIndex = i;
					}

					//no interpolation
					if( !frame.b && percent != 0.0 ) { //without interpolation, TODO prohibit deletion of 0.0 frame
						percent = percent - 0.01;
						k += percent+"% {\n\t";
						k += prevStyle + prevStyle1;
						k += "}\n";
					} else if( prevFrame && frame.p != prevFrame.p && percent != 0.0 ) { //new frame with old position of background
						percent = percent - 0.01;
						k += percent+"% {\n\t";
						k += style + prevStyle1;
						k += "}\n";
					}
					k += f;
					prevFrame = frame;
					prevStyle = style;
					prevStyle1 = style1;
					prevStyle2 = style2;
				}
			}
			//100% explicit frame
			var frame = this.timeFrames[maxIndex];
			if(frame.t != toTime) {
				frame = this.findLastDefinedTimeFrameOrInterpolate(toTime); //TODO test maybe too inacurate
				k += "100% {\n\t";
				sprite.applyFrame(frame);
				var style = sprite.updateCss3(options);
				var style1 = sprite.updateCss3Sprite(options);
				k += style + style1;
				k += "}\n";
			}
			//0%explicit frame
			var frame = this.timeFrames[minIndex];
			if(frame.t != fromTime) {
				frame = this.findLastDefinedTimeFrameOrInterpolate(fromTime); //TODO test maybe too inacurate
				k1 += "0% {\n\t";
				sprite.applyFrame(frame);
				var style = sprite.updateCss3(options);
				var style1 = sprite.updateCss3Sprite(options);
				k1 += style + style1;
				k1 += "}\n";
			}

			k += "}\n";
			var body = k1 + k;
			this.css3Keyframes = head + body;
			if(isOpera)
				this.css3KeyframesBodies[timeKey] = body;
			
			if(isEdit() && this.styleBlock) {
				this.styleBlock.remove();
			}
			this.styleBlock = $("<style type='text/css'>"+this.css3Keyframes+"</style>").appendTo("head");
		}
		
		 /**
		 * @ignore
		 */
		this.startCss3 = function(css3KeyframesName, duration) {
			if(!isAnimationLoop)
				this.sprite.imgObj.addClass("css3Paused");
			this.sprite.styleToPlay = {
				"animation": css3KeyframesName+" "+duration+"s linear",
				"-webkit-animation": css3KeyframesName+" "+duration+"s linear"
			};
//			this.sprite.styleToPlay = {
//			"animation-name":css3KeyframesName, "animation-duration":duration+"s", "animation-timing-function":"linear",
//			"-webkit-animation-name":css3KeyframesName, "-webkit-animation-duration":duration+"s", "-webkit-animation-timing-function":"linear"
//			};
//			this.sprite.imgObj.css({"animation-name":css3KeyframesName, "animation-duration":duration+"s", "animation-timing-function":"linear"});					
		}
		
	}

 /**
 * @ignore
 */
function loadImage(jqTmpImg, jqImg, isOldIE, isFromSaved) {
				var sprite = jqTmpImg.data("sprite");
				sprite.width = jqTmpImg.width();
				sprite.height = jqTmpImg.height();
				sprite.scaleTo(sprite.scale, true);
				if(isOldIE) {
					sprite.imgObj.append(jqImg);
				}
//				jqImg.pngFix();
				
				var imageName = jqTmpImg.attr("class");
				jqTmpImg.remove();
				sprite.alignHandles();
				//h5
				jqTmpImg.data("width", sprite.width);
				jqTmpImg.data("height", sprite.height);
				MXKIMAGES.addImage(imageName, jqTmpImg);
				//js + css3
				MXKIMAGES.addImageClass(imageName, jqTmpImg.attr("src"), sprite.width, sprite.height );
//TODO showonupdate				sprite.show();
//				if(isEdit() && !isFromSaved) {
				if(isEdit() ) {
					$(".sprite_image_auto").autocomplete("option", "source", MXKIMAGES.getImageNames()); 				
					$("#sprite_image_auto").val(imageName); //todo maybe inside something
//					if(!isFromSaved)
//						MXKEDITOR.projectTabToFrame(sprite.index);
//					else
						MXKEDITOR.sprites[sprite.index].setImage(imageName);
					sprite.update();
					MXKEDITOR.showCurrentThumb();
				} else {
					sprite.setImage(imageName);
					sprite.update();
				}
//TODO showonupdate				sprite.update();
				MXKIMAGES.lImgs--; //decrement loading images
//				$('#logger').append(" -"+imageName);

}	


 /**
 * @ignore
 */
function loadImageCanvas(jqTmpImg, isOldIE) {
				var canvas = jqTmpImg.data("canvas");
				var imageName = jqTmpImg.attr("class");
				if(isOldIE) {
					var width = jqTmpImg.get()[0].width;
					var height = jqTmpImg.get()[0].height;
				} else {
					var width = jqTmpImg.width();
					var height = jqTmpImg.height();
				}
				jqTmpImg.remove();
				MXKIMAGES.addImageClass(imageName, jqTmpImg.attr("src"), width, height );
				if(isEdit() ) {
					$("#sprite_image_auto").autocomplete("option", "source", MXKIMAGES.getImageNames()); 				
					$("#canvas_image_auto").autocomplete("option", "source", MXKIMAGES.getImageNames()); 				
					$("#canvas_image_auto").val(imageName); //todo maybe inside something
				}
				canvas.setImage(imageName);
				MXKIMAGES.lImgs--; //decrement loading images
//				$('#logger').append(" -"+imageName);
}	

	
/**
 * @ignore
 */
function toRad(x) {
	return x * (Math.PI/180);
}

var mxkSrc = null;
/**
 * @ignore
 */
function getOriginalSources() {
	var srcUrl = $("#mxk_animation").attr("src");
	if(!srcUrl) //only if responsivenes is enabled
		return;
	$.ajax({ 
		url: srcUrl, 
		type: "GET", 
		dataType: "text", 
		success: function(data) { 
			mxkSrc = data;
		},
		error: function(res) {
			console.log("[Mixeek] Failed to load animation script on resize");
		}
	});
}

//var once = true;
var isFullReload = false;
var isReloadQueued = false;
/**
 * Co se ma stat v pripade resize?
 * JS + H5 -> calcScale applyStyle
 * CSS3 -> drop everything and restore everything from the beginning
 * @ignore
 */
function bindResize() {
	$(document).ready(function(){
		if(isCSS3)
			getOriginalSources();
	});
	$(window).resize(function() { //TODO SCALING
//		console.log('RESIZE');
		if(isCSS3) {
			var isScale = false;
			for(var i in canvases) {
				if(canvases[i].scaleToParent && canvases[i].calcScale()) {
					isScale = true;
					break;
				}
			}
			if(isScale && canvases.length) {
				fullReload();
			}
		} else { //JS + H5
			for(var i in canvases) {
				var can = canvases[i];
				if(can.scaleToParent && can.calcScale()) {
					can.applyStyle();
					//touch sprites
					if(isH5) {
						for(var name in can.sprites) {
							var sprite = can.sprites[name];
							sprite.positionApply = true;
						}
						redrawH5(true);
					} else { //JS
						stopAnimationLoop();
						for(var name in can.sprites) {
							var sprite = can.sprites[name];
							sprite.positionApply = true;
							sprite.update();
						}
						startAnimationLoop();
					}
				}
			}
		}
			
	});	
}
	
/**
 * @ignore
 */
function fullReload() {
	if(isFullReload) {
		colole.log('RELOADING');
		if(isReloadQueued) {
			colole.log('QUEUED');
			return;
		} else {
			colole.log('PUT QUEUE');
			isReloadQueued = true;
			setTimeout(function() {fullReload();}, 200);
		}
	}
	isFullReload = true;
	isReloadQueued	= false;
//	mozReload = true;
	if(!mxkSrc) //only if responsivenes is enabled
		return;
	if(!canvases.length)
		return;
//				stopAnimationLoop();
	for(var i in canvases) {
		canvases[i].canvasDiv.remove();
	}
	canvases = [];
	spriteRegistry = {};
	runningRegistry = {};
	MXKIMAGES = new MxkImageCache();
	MXKSOUNDS = new MxkSoundCache();
	eval(mxkSrc); //use preloaded sources
	$(document).ready(function() {
		console.log('finish reload');
		isFullReload = false;
	});
//	$(document).ready();
//				setTimeout(function() {startAnimationLoop();}, 1000);
//				startAnimationLoop();
}
	
/**
 * @ignore
 */
function sortH5(array) {
	for (var i = 0; i < array.length - 1; i++) {
		for (var j = 0; j < array.length - i - 1; j++) {
			if(array[j].zIndex > array[j+1].zIndex){
				var tmp = array[j];
				array[j] = array[j+1];
				array[j+1] = tmp;
			}
		}
	}			
}

var beziers = {};
var bCount = 400;
var a1 = [0,0];
var a2 = [1,1];
function getBKey(x1,y1,x2,y2) {
	return "" + x1 + y1 + x2 + y2;
}
function preCalcBez(frameE) {
	var x1 = frameE[0]; 
	var y1 = frameE[1]; 
	var x2 = frameE[2]; 
	var y2 = frameE[3]; 
	if(!(frameE instanceof Array)) {
		alert('Frame easing "e" is supported only as cubic-bezier array format since 2.1 release, e.g. "e":[0.25,0.1,0.25,1] as a replacement for "ease"');
		return;
	}
	var line = [];
	for(var i = 0; i<bCount; i++) {
		var point = cubicBezier( [x1,y1], [x2,y2], i/bCount);
//		line.push(point);
		line[  Math.round(point[0] * bCount) ] = point[1];
	}
	line[bCount-1] = 1.0;
	var key = getBKey(x1,y1,x2,y2);
	beziers[key] = line;
}
/*Return bezier progres*/
function getBY(x1,y1,x2,y2,relTime) { //relTime 0..1
	var key = getBKey(x1,y1,x2,y2);
	var line = beziers[key];
	var index = Math.round( relTime * bCount );
	var y = line[ index ];
	if(y != undefined)
		return y;
	var i,j,y0,y1;
	for(i = index-1; i>=0; i--) {
		y0 = line[i];
		if(y0) break;
	}
	for(j = index+1; j<bCount; j++) {
		y1 = line[j];
		if(y1) break;
	}
	var ratio = (index-i) / (j-i);
	return y0 + (y1-y0)*ratio;
}
/*cubic-bezier(x1,y1,x2,y2)*/
function cubicBezier(c1, c2, progres) {
//	var point = bezierC(progres, a1, a2, c1, c2);
	var point = bezierC(progres, a1, c1, c2, a2);
	return point;
}

function bezierC(t, p0, p1, p2, p3) {
	var posx = Math.pow(1-t,3)*p0[0] + 3*Math.pow(1-t,2)*t*p1[0] + 3*(1-t)*t*t*p2[0] + t*t*t*p3[0];
	var posy = Math.pow(1-t,3)*p0[1] + 3*Math.pow(1-t,2)*t*p1[1] + 3*(1-t)*t*t*p2[1] + t*t*t*p3[1];
	return [posx, posy];
}
function bezier(u, anchor1, anchor2, control1, control2) {
	var posx = Math.pow(u,3)*(anchor2[0]+3*(control1[0]-control2[0])-anchor1[0])
			   +3*Math.pow(u,2)*(anchor1[0]-2*control1[0]+control2[0])
			   +3*u*(control1[0]-anchor1[0])+anchor1[0];
	 
	var posy = Math.pow(u,3)*(anchor2[1]+3*(control1[1]-control2[1])-anchor1[1])
			  +3*Math.pow(u,2)*(anchor1[1]-2*control1[1]+control2[1])
			  +3*u*(control1[1]-anchor1[1])+anchor1[1];
	return [posx, posy];
}
/*function bezier(u, anchor1, anchor2, control1, control2) {
	var posx = Math.pow(u,3)*(anchor2.x+3*(control1.x-control2.x)-anchor1.x)
			   +3*Math.pow(u,2)*(anchor1.x-2*control1.x+control2.x)
			   +3*u*(control1.x-anchor1.x)+anchor1.x;
	 
	var posy = Math.pow(u,3)*(anchor2.y+3*(control1.y-control2.y)-anchor1.y)
			  +3*Math.pow(u,2)*(anchor1.y-2*control1.y+control2.y)
			  +3*u*(control1.y-anchor1.y)+anchor1.y;
	return {x:posx,y:posy};
}*/


	
$(document).ready(function(){
//	cubicBezier(0.8, 0.2, 0.2, 0.8, 0.2);
//	cubicBezier(0.8, 0.2, 0.2, 0.8, 1);
//	cubicBezier(0.8, 0.2, 0.2, 0.8, 0.5);
	//canvas (default)
//	MXKCANVAS = new MxkCanvas( "body", 800, 400, "background-color: #eeeeee; position: absolute; top:100px;	left : 100px;" ); 
	//image cache
	MXKIMAGES = new MxkImageCache();
	MXKSOUNDS = new MxkSoundCache();
	bindResize();
	
});
	