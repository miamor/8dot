describe("Integration", function() {
  var appController;

  beforeEach(function() {
    // appController = new mindmaps.ApplicationController();
  });

  it("should work", function() {
    
  });
});
