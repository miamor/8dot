/** @constructor */
pack = function() {
	this.init = function(){}
	function config(){}
}
 
 pack.build = function(task) {};

/** @memberOf pack */
pack.install = function() {}

/** @memberOf pack */
pack.install.overwrite = function() {}

/** @memberOf pack */
clean = function() {}

/** @memberOf pack-config */
install = function() {};
