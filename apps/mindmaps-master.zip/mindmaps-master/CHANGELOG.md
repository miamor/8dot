# Changelog

## 2012-06-24
- Added integration with Dropbox and other cloud storage services (finally!)

## 2012-04-25
- Added feature to set the branch color of all children to the parent's color
- Branch and font color changes now happen on-the-fly when using the colorpicker

## 2012-02-13
- Added auto save feature for LocalStorage

## 2012-01-21
- Added Shortcuts for Mac OSX users

## 2011-08-09
- Implemented PNG export
- Added support for printing the mind map
