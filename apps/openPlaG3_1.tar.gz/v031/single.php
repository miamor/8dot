<?= '<?xml version="1.0" encoding="UTF-8"?>' ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
/*
#########################################################
#############   openPlaG 3.1: single.php   ##############
#########################################################
#############   written by Juergen Kummer   #############
#########################################################
##############   published under GNU GPL   ##############
#########################################################
Original source: http://rechneronline.de/function-graphs/
#########################################################
Copyright (C) 2011 Juergen Kummer

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

/*
This file feeds a given function with one single input value and writes the result.
It is hosted in an iframe on the main page.
*/
?>
<head>
<title></title>
<meta http-equiv="expires" content="0" />
<meta name="robots" content="noindex,nofollow" />
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="graph.css" type="text/css" />
<style type="text/css">
td{font-size:13px;text-align:right}
th{font-size:13px;text-align:center}
</style>
</head>
<body style="width:650px;height:50px;margin:0px;padding:0px;background-color:#dedede;text-align:center;vertical-align:middle">
<?php

// get variables
$c=$_POST['c'];
$qqsingle=$_POST['qqsingle'];
$single1=$_POST['single1'];
$inpval=$_POST['inpval'];
$decis=$_POST['decis'];
$format=$_POST['format'];

// transform formula and input value,
// to make it understandable by PHP
if(!$inpval) $inpval=0;
if(!$single1)
	die('<br />Result</body></html>');
if($single1!=str_replace('D','',$single1) || $single1!=str_replace('S','',$single1) || $single1!=str_replace('phi','',$single1))
	die('<br />_</body></html>');
$orgvals=explode(" ",$inpval);
$inpval=trim($inpval);
while($inpval!=str_replace("  "," ",$inpval))
	$inpval=str_replace("  "," ",$inpval);
$formula1=$single1;
$inpval=str_replace(',','.',$inpval);
$inpval=str_replace('pi2',M_PI_2,$inpval);
$inpval=str_replace('pi',M_PI,$inpval);
$inpval=str_replace('e',M_E,$inpval);
$inpval=str_replace('sq2',M_SQRT2,$inpval);
$inpval=str_replace('go',1.6180339887499,$inpval);
$inpval=str_replace('d',4.6692016091030,$inpval);
$inpvals=explode(" ",$inpval);

$qq=$qqsingle;//substituted formulas should be calculable too
$single=1; //we don't want to compute the whole graph, only a single value
include 'init.php';

// do the calculation and echo the result
$i=0;
if($format==1) {//table output
	echo '<table cellspacing="0" cellpadding="1" border="1"><tr><th>x </th>';
	foreach($orgvals as $val) 
		echo "<td>&nbsp;$val&nbsp;</td>";
	echo "</tr>\n<tr><th>$single1 </th>";
}
else if($format==2)//csv output
	echo"x;$single1<br/>\n";
foreach($inpvals as $val) {
	$erg=graph($val,$formula[0]);
	if($erg==999999) echo $text2;
	else if($bracketerror[0]) echo $text5;
	else if(is_numeric($erg)) {
		$erg=round($erg,$decis);
		if(!$format)
			echo '<span title="'.$orgvals[$i].' -> '.$single1.' = '.$erg.'">'.$erg.'</span> ';
		else if($format==1)
			echo "<td>&nbsp;$erg&nbsp;</td>";
		else if($format==2)
			echo "$orgvals[$i];$erg<br />\n";
	}
	else if(!$format)
		echo '<span title="undefined">_</span> ';
	else if($format==1)
		echo '<td>&nbsp;_&nbsp;</td>';
	else if($format==2)
		echo "$val;<br />\n";
	if($i<count($inpvals)-1 && !$format)
		echo '| ';
	++$i;
}
if($format==1)
	echo '</tr></table>';

?>
</body>
</html>